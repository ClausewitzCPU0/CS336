# Course Note Input & Packaging Contract v4.9.4

本 contract 把每章 prompt 中反复出现的输入发现、来源核验、官方编号映射、配套资料和打包规则下沉到 workflow。目标是让用户只需要说明**课程在哪里**以及**本次处理哪一章**，其余可复用执行规则由 workflow 负责。

## 1. 最小用户输入

一次章节任务原则上只需要：

- 课程名称或可唯一定位的 course root；
- 本地章节标识，例如 `P11`、`chapter 20`；
- 若 workflow / course profile 不在约定位置，提供其路径；
- 只有用户要求覆盖默认行为时，才额外给出特殊规则。

以下内容不要求每章重复声明：

- ASR 可能有误；
- XML / 弹幕仅作待核查线索；
- 允许使用官方材料交叉核查；
- 纯文字 slide 转为 Markdown；
- coverage assets 不必全部嵌入正文；
- 最终必须 QA、打包并给出 ZIP；
- workflow 版本必须进入笔记元信息；
- 来源不匹配或必要文件不可访问时必须停止。

## 2. Course profile

课程级、跨章节稳定的信息应优先放入 `course-profile.yaml`，而不是每章重复输入。

推荐字段：

```yaml
schema_version: 1
course_name: Example Course
instructor: Example Instructor

# optional: auto | mathematics | computer_science | mixed | other
content_domain: auto

lecture_video_term: Fall 2027
official_materials_term: Fall 2027

official_course_url: https://example.edu/course
official_video_index_url: https://example.edu/course/videos
local_video_collection_url: null

drive_root: path/to/course

official_unit_label: Lec
numbering:
  local_chapters: sequential
  official_units: sequential
  may_have_gaps: false
  # optional local-label -> official-unit-number exceptions, e.g. P25: "24b"
  mapping_overrides: {}

provenance_note: null
```

规则：

1. profile 是 reusable context，不是事实来源的替代品；需要时仍应打开官方页面核验。
2. profile 缺失时，不得编造字段。可以根据用户明确提供的课程背景在本次会话内建立临时 course context。
3. 若 course root 内存在 `course-profile.yaml`，默认读取；用户显式信息优先于旧 profile。
4. 不同学期、不同版本材料必须分别记录，例如 `lecture_video_term` 与 `official_materials_term`，不得因为共享一个课程网页就合并为同一 provenance。
5. `content_domain` 是可选 completeness hint，不是来源事实；`auto` 时根据本讲实际内容决定数学/计算机/混合义务，不得为了匹配 domain 补写源中不存在的内容。
6. `numbering.mapping_overrides` 只保存少量、跨章节稳定的编号例外，例如 `P25: "24b"`。它是 discovery hint，不是官方事实的替代品；每章 Chapter Identity Preflight 仍须用官方 schedule/video index 核验。

## 3. 输入发现与章节文件配对

给定 course root 与本地章节标识后，按以下顺序发现输入：

1. 直接存在的章节文件，例如 `.mp4`、`.srt`、`.vtt`、`.xml`、课件、PDF；
2. 单一章节归档，例如 `.zip`；
3. multipart archive，例如 `.zip.001`、`.zip.002`；
4. 用户明确给出的其他容器格式。

### 3.1 Required input set 与 exact-file precedence

如果用户明确列出本次文件名，**在调用 connector 前先冻结 required input set**。例如：

```text
[P02]Lec1b：计算过程.mp4
[P02]Lec1b：计算过程.srt
[P02]Lec1b：计算过程.xml
```

规则：

- 用户明确给出的 basename 是最高优先级 identity hint；必须先尝试定位 exact basename；
- basename、本地章节标识、标题、文件类型和内容共同用于最终配对，但不得因为发现“看起来是同一 Lecture”的其他副本，就提前放弃 exact basename；
- `[P02]...` 与 `[P22]...`、`原版` 与 `外挂字幕版`、重复上传副本等必须视为不同 source candidate；
- **只有在 exact target 经过完整可用的目录发现路径后仍不存在或不可读取，并且用户意图允许替代时，才可以考虑同章节副本**；采用替代源必须在 `audit/sources.json` 和最终报告中说明理由；
- required `.mp4/.srt/.vtt` 缺失时按原 contract fail fast；XML / 弹幕仍是 optional evidence，除非用户显式把它提升为 required input。

### 3.2 Directory enumeration completeness

**全局搜索 miss 不等于文件不存在；单次目录 listing 返回 N 项也不等于目录总共有 N 项。**

目录发现必须区分：

- `requested_limit`：本次工具调用要求扫描/返回的最大数量；
- `returned_count`：实际返回数量；
- `complete_for_connector`：是否已有足够证据认为当前 connector 已枚举完该目录。

执行规则：

1. course root/目标目录已知时，filename/full-text search 没有命中不得直接判定 `required source missing`；进入目录枚举 fallback。
2. 若 connector 支持分页，则持续使用 provider 返回的 page token，直到没有下一页。
3. 若 connector 不暴露分页、但允许提高 `top_k` / `limit`：
   - 不使用默认值作为目录总量判断；
   - 当 `returned_count == requested_limit` 时，状态必须记为 `possibly_truncated`；
   - 提高上限后重新枚举，直到 `returned_count < requested_limit`、工具明确给出 complete/no-next-page，或达到 connector 实际能力边界；
   - **不得因为恰好返回 100 项就声称“目录最多只能枚举 100 项”。**
4. 当前 ChatGPT Web Google Drive connector 的已验证行为：`list_folder` 默认/常用上限为 100，但 `top_k` 可以显式提高；在 SICP 真实 course root 中，`top_k=300` 一次返回 108 个直接子项。因此本 workflow 对该 connector 的推荐初始值是 `top_k=300`；若仍满足 `returned_count == top_k`，继续提高，而不是停在 300。
5. 对大目录，工具结果返回后应立即在代码/工具编排层按 exact basename、本地章节标识和扩展名过滤，只把命中候选带入模型上下文；不要为了“让模型自己找”而输出数百个无关项目。
6. 对方括号、中文标题、全角标点或特殊字符导致 search 不稳定时，目录枚举的 exact basename match 优先于反复尝试长搜索词。
7. 只有所有当前可用的完整枚举/分页/扩大上限路径都已尝试，仍无法定位 required input，才允许判定文件缺失。

SICP 回归例：目录实际有 108 个项目。`top_k=100` 恰好返回 100 项时漏掉 P02 的 `.mp4/.xml`；提高到 `top_k=300` 后返回 108 项并找到 P02 `.mp4/.srt/.xml`。因此 `100/100` 是截断信号，不是目录规模证明。

### 3.3 通用配对与完整性规则

- 优先使用 basename、本地章节标识、标题和内容共同配对；
- 上传顺序、文件创建顺序和重复后缀不能作为唯一配对依据；
- 不允许从相邻章节拿同类型文件补缺；
- multipart archive 必须先确认所有必要分卷齐全，再重建和解压；缺卷立即停止；
- 若 connector 无法完整 materialize 某个 required source，又不存在可完整重建的 multipart representation，则停止任务，不得使用截断文件继续生成。

不要把某个当前平台的固定单文件大小上限写进 workflow；能力边界以实际 connector/materialization 结果为准。

## 4. Chapter Identity Preflight

**任何全程 2 秒 base index 或其他高成本 semantic discovery 之前，必须先做章节身份预检。**

预检至少包括：

1. 确认本地目标：`chapter_index`、本地文件名/标题；
2. 检查视频容器、时长和可解码性；
3. 检查字幕时间轴是否覆盖相同视频时长范围；
4. 检查视频开头可见标题、教师口述、硬字幕或 SRT 中出现的 lecture/session/module 编号与主题；
5. 抽查开头、中段、末段的字幕与视频是否时间对齐；
6. 若官方课程目录、schedule 或 video index 可用，建立 `local chapter -> official unit` 映射；若 profile 存在 `numbering.mapping_overrides`，先把它作为候选映射提示，再用官方 index 复核；
7. 检查官方编号是否存在 gap，以及本地连续编号是否因此产生 offset；profile override 与官方页面冲突时以本次官方核验为准，并在报告中指出 profile 需要更新；
8. 检查目标主题与视频实际主题是否一致。

推荐的身份记录：

```json
{
  "chapter_index": 10,
  "local_label": "P10",
  "official_unit_label": "Lec",
  "official_unit_number": 11,
  "official_title": "Max-min",
  "identity_status": "confirmed",
  "evidence": []
}
```

### 4.1 Fail-fast 条件

以下任一情况出现时，必须在构建 base index 前停止：

- 视频和字幕明显属于不同章节；
- 本地标题与视频实际 lecture/session 明显冲突；
- 官方目录与视频内可确认编号冲突；
- required input 缺失、损坏、截断或不可完整读取；
- multipart archive 缺卷；
- 无法在合理证据下确认目标章节身份，继续处理会有较高错章风险。

停止时应说明：发现了什么、依据是什么、需要用户替换或补充哪个文件。不得为了完成任务而猜测映射。

## 5. 字幕与硬字幕 evidence policy

字幕来源至少区分：

- `official_transcript`
- `human_subtitle`
- `asr_subtitle`
- `unknown_subtitle`
- `hard_subtitle`

`.srt` 扩展名本身不代表字幕可信度。

对以下高风险信息，ASR / unknown subtitle 不得未经核查直接定稿：

- 数字、日期、单位；
- 数学公式、符号、上下标、比较关系；
- 专有名词、人名、论文名；
- API、命令、identifier、代码 token；
- 否定词和条件词；
- 关键结论、边界条件、例外情况。

若视频存在清晰硬字幕：

1. 回看对应 original-resolution frame；
2. 将硬字幕作为独立交叉证据；
3. 若硬字幕与音频/官方材料冲突，不得因为“写在画面上”就自动判定硬字幕正确；
4. 结论仍按 source-native evidence、上下文和官方资料综合确认。

XML / 弹幕 / 评论只允许作为待核查线索，不进入 generation allowlist 的权威层级。

## 6. Official Material Discovery

当网络访问可用且用户未禁止联网时，workflow 应主动从官方课程入口发现与本讲明确关联的材料，而不要求用户逐项提供链接。

优先寻找：

- course schedule / syllabus；
- lecture/video index；
- lecture notes / slides；
- chapter-specific handout；
- assigned reading / paper；
- 官方代码仓库或示例文件。

来源优先级：

```text
本讲原始视频 / 可确认字幕 / 可见课件状态
> 本讲同版本或同学期官方材料
> 官方课程其他版本材料
> 其他正式资料
> 第三方资料
> 弹幕 / 评论
```

不同年份或版本材料只能作为补充，并在笔记中保留 provenance。不得把别的学期讲义内容写成“本讲教师明确讲了”。

## 7. Official unit mapping 与命名

### 7.1 默认命名

当本地章节编号与官方单元编号属于同一个连续编号空间：

```text
<chapter-index>-<chapter-title>
```

例如：

```text
06-软件工程的来龙去脉
```

### 7.2 双编号命名

当课程同时存在**本地连续章节序号**和**官方非连续或不同编号空间**时：

```text
<chapter-index>-<official-unit-label>-<official-unit-number>-<official-title>
```

例如：

```text
10-Lec-11-Max-min
```

`official-unit-label` 不能写死为 `Lec`；根据课程使用 `Lec`、`Week`、`Session`、`Module` 等官方或用户约定标签。

字段语义：

- `chapter-index`：本地笔记系列连续排序；
- `official-unit-number`：官方课程编号；
- `official-title`：官方课程网页对应标题；
- 本地标题可进入元信息，但不得替换官方标题字段。

对文件系统非法字符做 deterministic sanitize；不得因此改变章节语义。

## 8. 最终 artifact basename 与目录结构

先得到唯一的 `artifact_basename`，然后统一用于 ZIP、解压目录和主 Markdown：

```text
<artifact_basename>.zip

<artifact_basename>/
  <artifact_basename>.md
  assets/
    coverage/
  papers/
  audit/
```

`audit/` 可以保留 source ledger、coverage ledger 和 package audit，但不得把内部审计标记泄漏到主 Markdown。

## 9. Coverage assets packaging

`slide-coverage.jsonl` 中所有 `decision=retain` 的视觉资产都必须：

- 实际存在；
- 保留在最终 ZIP 的 `assets/coverage/`；
- 满足 full-frame contract。

**retained asset 不等于必须嵌入正文。**

正文只引用有明确阅读价值的图片；其他 retained coverage assets 作为 visual completeness fallback 留在 package 中。不得因为正文没有引用某张 retained asset 就把它从 ZIP 删除。

## 10. Chapter-level paper / reading packaging

若官方 schedule / lecture page 明确把某 PDF 标为本讲的 paper、assigned reading 或 required reading：

1. 将可下载 PDF 保存到 `papers/`；
2. 在主 Markdown 顶部的“配套资料”区域使用相对链接引用；
3. 论文内容默认不强制并入课堂正文；只有本讲实际讲到或用户明确要求时才综合；
4. 课程级 bibliography 中没有明确 chapter association 的 PDF 不自动打包；
5. 若官方页面明确要求本讲论文但 PDF 无法完整获取，不得静默省略，必须在最终报告中说明。

## 11. 强制元信息

主 Markdown 顶部必须包含可读、可机器搜索的生成元信息。推荐 YAML front matter：

```yaml
---
workflow:
  name: ChatGPT-Web-Course-Note-Workflow
  version: v4.9.4
course:
  name: Example Course
  instructor: Example Instructor
chapter:
  index: 10
  local_label: P10
  official_unit_label: Lec
  official_unit_number: 11
  official_title: Max-min
provenance:
  lecture_video_term: Fall 2007
  official_materials_term: Fall 2006
---
```

未知字段写 `null` 或省略，不得猜测。workflow name/version 不得省略。

## 12. Final package gate

打包前必须确认：

- chapter identity 已确认；
- required sources 完整且配对正确；
- base index complete；
- source atom / semantic / visual obligations 已检查；
- retained coverage assets 全部在 package 中；
- 需要打包的 chapter-level paper 已处理；
- 主 Markdown reader-facing sanitation PASS；
- workflow 元信息存在；
- artifact basename 符合 numbering contract；
- ZIP 可以列出并完整解压；
- 最终 ZIP 计算 SHA-256。

## 13. 最终 Web 回复

保持简短但信息完整：

- 执行结果与章节身份；
- 本次遇到的问题，仅在存在时列出；
- 笔记覆盖内容的简要概述；
- workflow observation，仅在本次确实发现可复用问题时给出；
- ZIP 下载链接；
- ZIP SHA-256。

不要为了满足模板强行编造 workflow 改进建议。
