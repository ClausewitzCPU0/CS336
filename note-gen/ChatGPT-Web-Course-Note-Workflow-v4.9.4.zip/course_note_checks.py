#!/usr/bin/env python3
"""Deterministic final-artifact checks for Course Note Workflow v4.9.4.

Checks reader-facing Markdown, workflow metadata, artifact naming, retained
coverage assets, and (when requested) full-frame image geometry. Semantic
coverage and chapter identity remain evidence-based review tasks and are not
claimed to be mechanically proven by this script.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

IMAGE_RE = re.compile(r"!\[[^\]]*\]\(([^)]+)\)")
PAPER_LINK_RE = re.compile(r"(?<!!)\[[^\]]+\]\((papers/[^)]+\.pdf(?:#[^)]*)?)\)", re.I)
HTML_COMMENT_RE = re.compile(r"<!--.*?-->", re.S)
AUDIT_ANCHOR_RE = re.compile(r"<a\s+id\s*=", re.I)
INTERNAL_ID_RE = re.compile(r"\b(?:episode_id|atom_id|source_state_id|action_id)\b")
BAD_MATH_RE = re.compile(r"\\\[|\\\]|\\\(|\\\)")
WORKFLOW_NAME_RE = re.compile(r"ChatGPT-Web-Course-Note-Workflow")
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp"}


def probe_size(path: Path) -> tuple[int, int]:
    proc = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=width,height",
            "-of",
            "json",
            str(path),
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or f"ffprobe failed: {path}")
    data = json.loads(proc.stdout)
    streams = data.get("streams") or []
    if not streams:
        raise RuntimeError(f"no video/image stream: {path}")
    return int(streams[0]["width"]), int(streams[0]["height"])


def _clean_link_target(raw: str) -> str:
    target = raw.split()[0].strip("<>")
    target = target.split("#", 1)[0]
    return target


def check_notes(
    notes_path: Path,
    expected_workflow_version: str | None,
    artifact_basename: str | None,
) -> list[str]:
    errors: list[str] = []
    text = notes_path.read_text(encoding="utf-8")

    if HTML_COMMENT_RE.search(text):
        errors.append("reader-facing notes contain HTML comments (forbidden by the current workflow contract)")
    if AUDIT_ANCHOR_RE.search(text):
        errors.append("reader-facing notes contain internal <a id=...> anchors")
    if INTERNAL_ID_RE.search(text):
        errors.append("reader-facing notes contain internal audit field names")
    if BAD_MATH_RE.search(text):
        errors.append("reader-facing notes use disallowed LaTeX delimiters; use $...$ or $$...$$")

    if expected_workflow_version:
        if not WORKFLOW_NAME_RE.search(text):
            errors.append("workflow metadata missing ChatGPT-Web-Course-Note-Workflow name")
        version_re = re.compile(
            rf"(?:^|\n)\s*version\s*:\s*['\"]?{re.escape(expected_workflow_version)}['\"]?\s*(?:\n|$)",
            re.I,
        )
        if not version_re.search(text):
            errors.append(f"workflow metadata missing version: {expected_workflow_version}")

    if artifact_basename:
        expected_name = f"{artifact_basename}.md"
        if notes_path.name != expected_name:
            errors.append(
                f"main Markdown filename mismatch: got {notes_path.name}, expected {expected_name}"
            )
        if notes_path.parent.name != artifact_basename:
            errors.append(
                f"package root basename mismatch: got {notes_path.parent.name}, expected {artifact_basename}"
            )

    for raw in IMAGE_RE.findall(text):
        target = _clean_link_target(raw)
        if not target or "://" in target or target.startswith("data:"):
            continue
        p = (notes_path.parent / target).resolve()
        if not p.exists():
            errors.append(f"missing referenced image: {target}")

    for raw in PAPER_LINK_RE.findall(text):
        target = _clean_link_target(raw)
        p = (notes_path.parent / target).resolve()
        if not p.is_file():
            errors.append(f"missing referenced paper PDF: {target}")

    return errors


def check_coverage_ledger(ledger_path: Path, package_root: Path) -> tuple[list[str], int]:
    errors: list[str] = []
    retained = 0
    try:
        lines = ledger_path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        return [f"cannot read coverage ledger: {exc}"], 0

    for lineno, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError as exc:
            errors.append(f"invalid JSON in coverage ledger line {lineno}: {exc}")
            continue
        if item.get("decision") != "retain":
            continue
        retained += 1
        asset_path = item.get("asset_path")
        if not asset_path:
            errors.append(f"retained coverage item line {lineno} has no asset_path")
            continue
        asset = (package_root / asset_path).resolve()
        if not asset.is_file():
            errors.append(f"retained coverage asset missing: {asset_path}")
        if item.get("capture_mode") != "full_frame":
            errors.append(f"retained coverage item line {lineno} is not capture_mode=full_frame")
        source_size = item.get("source_frame_size")
        asset_size = item.get("asset_frame_size")
        if source_size and asset_size and source_size != asset_size:
            errors.append(
                f"coverage ledger geometry mismatch line {lineno}: "
                f"source_frame_size={source_size}, asset_frame_size={asset_size}"
            )
    if retained == 0:
        errors.append("coverage ledger contains no retained assets")
    return errors, retained


def check_full_frame_assets(
    source_video: Path, coverage_dir: Path
) -> tuple[list[str], tuple[int, int], int]:
    errors: list[str] = []
    source_size = probe_size(source_video)
    assets = sorted(
        p for p in coverage_dir.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES
    )
    if not assets:
        errors.append(f"no coverage images found: {coverage_dir}")
        return errors, source_size, 0

    for asset in assets:
        try:
            size = probe_size(asset)
        except Exception as exc:
            errors.append(f"cannot probe coverage image {asset.name}: {exc}")
            continue
        if size != source_size:
            errors.append(
                f"coverage image is not full-frame: {asset.name} is {size[0]}x{size[1]}, "
                f"source is {source_size[0]}x{source_size[1]}"
            )
    return errors, source_size, len(assets)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("notes", help="path to final main Markdown")
    ap.add_argument("--source-video", help="source video for full-frame geometry check")
    ap.add_argument("--coverage-dir", help="directory containing final coverage assets")
    ap.add_argument("--coverage-ledger", help="audit/slide-coverage.jsonl")
    ap.add_argument(
        "--expected-workflow-version",
        default="v4.9.4",
        help="required workflow version in Markdown metadata (default: v4.9.4)",
    )
    ap.add_argument(
        "--artifact-basename",
        help="expected basename shared by package directory and main Markdown",
    )
    args = ap.parse_args()

    notes = Path(args.notes)
    if not notes.is_file():
        print(f"ERROR: notes file not found: {notes}", file=sys.stderr)
        return 2

    if bool(args.source_video) != bool(args.coverage_dir):
        print("ERROR: --source-video and --coverage-dir must be provided together", file=sys.stderr)
        return 2

    errors = check_notes(notes, args.expected_workflow_version, args.artifact_basename)
    full_frame_summary = None
    retained_summary = None

    if args.coverage_ledger:
        ledger = Path(args.coverage_ledger)
        if not ledger.is_file():
            print(f"ERROR: coverage ledger not found: {ledger}", file=sys.stderr)
            return 2
        ledger_errors, retained = check_coverage_ledger(ledger, notes.parent)
        errors.extend(ledger_errors)
        retained_summary = retained

    if args.source_video and args.coverage_dir:
        source_video = Path(args.source_video)
        coverage_dir = Path(args.coverage_dir)
        if not source_video.is_file():
            print(f"ERROR: source video not found: {source_video}", file=sys.stderr)
            return 2
        if not coverage_dir.is_dir():
            print(f"ERROR: coverage dir not found: {coverage_dir}", file=sys.stderr)
            return 2
        ff_errors, source_size, count = check_full_frame_assets(source_video, coverage_dir)
        errors.extend(ff_errors)
        full_frame_summary = (source_size, count)

    if errors:
        for e in errors:
            print(f"FAIL: {e}")
        return 1

    print("PASS: reader-facing deterministic checks")
    if args.expected_workflow_version:
        print(f"PASS: workflow metadata {args.expected_workflow_version}")
    if args.artifact_basename:
        print(f"PASS: artifact basename {args.artifact_basename}")
    if retained_summary is not None:
        print(f"PASS: retained coverage assets present {retained_summary}/{retained_summary}")
    if full_frame_summary is not None:
        (w, h), count = full_frame_summary
        print(f"PASS: full-frame coverage assets {count}/{count} at {w}x{h}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
