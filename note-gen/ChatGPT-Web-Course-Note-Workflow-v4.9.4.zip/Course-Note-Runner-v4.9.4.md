# Course Note Runner v4.9.4

适用环境：能够读取附件/连接器文件、执行 Python/ffmpeg、查看图片，并在需要时访问官方课程网页的 ChatGPT Web。所有关键输入必须实际可访问。

## 一次执行

1. 校验本包 `MANIFEST.txt`；只加载 v4.9.4 Production、Input & Packaging、Runner、`Video-Index-Cache-v4.9.4.md` 和只读 Benchmark，不混用旧版规则。
2. 读取：
   - `Course-Note-Production-v4.9.4.md`；
   - `Course-Note-Input-and-Packaging-v4.9.4.md`；
   - `Video-Index-Cache-v4.9.4.md`。
3. 建立课程上下文：
   - 若 course root 存在 `course-profile.yaml`，读取它；
   - 否则从用户明确提供的课程背景建立 session-local course context；
   - 不得猜测 instructor、term、official numbering 或 provenance。
4. 执行输入发现：
   - 若用户明确列出文件名，先冻结 required input set；
   - 直接文件；chapter ZIP；multipart ZIP；
   - 优先 exact basename + 本地章节标识 + 文件类型配对；
   - connector 全局搜索没有命中时，不得立即判定文件不存在；course root/目标目录已知时进入目录枚举 fallback；
   - 目录 listing 的默认/当前 `top_k` 不是目录总量：若 `returned_count == requested_limit`，视为 `possibly_truncated`，必须分页或提高上限后继续；
   - 当前 Google Drive connector 推荐先用 `top_k=300`；若仍返回恰好 300 项则继续提高，直到得到完整性证据或触达实际工具边界；
   - 在工具编排层立即按 exact basename / 章节标识 / 扩展名过滤，避免把大目录完整列表带入上下文；
   - 用户点名的 exact target 尚未完成上述穷尽查找前，不得以同 Lecture/同标题的其他副本替代；
   - 完成所有可用的完整枚举/发现 fallback 后仍无法定位 required input，或 required input 损坏、截断、缺卷、无法完整 materialize 时，才立即停止。
5. **在任何全程 2 秒 base index 之前执行 Chapter Identity Preflight：**
   - 检查视频可解码、时长；
   - 检查字幕时轴；
   - 检查开头可见标题/口述/硬字幕/SRT 中的 lecture/session/module 编号；
   - 抽查开头、中段、末段字幕与画面对齐；
   - 读取官方 schedule/video index，建立 local chapter -> official unit 映射；profile 中的 `numbering.mapping_overrides` 只能作为候选提示，必须用官方 index 复核；
   - 检查官方编号 gap / offset；
   - 检查视频主题是否与目标章节一致。
6. 若 preflight 发现错章、错字幕、官方映射冲突或无法可靠确认身份：**FAIL FAST**。说明证据和需要替换的文件，不继续构建 base index。
7. 身份确认后完成来源冻结：
   - 建立 `audit/sources.json` generation allowlist；
   - 区分原视频/字幕、同版本官方材料、其他版本官方材料、第三方资料、弹幕/评论；
   - 当网络可用且用户未禁止联网时，自动发现本讲官方 notes/slides/handout/paper/reading/code。
8. 建立或恢复全程 2 秒 base index：
   - 使用 `build_video_index.py`；
   - 默认 `segment=90s`、`interval=2s`、`workers=min(4, max(1, cpu_count-1))`、`threads-per-worker=1`；
   - 默认单次调用最多处理一个 worker batch；
   - 若仍有 pending segment，结束本次命令后再次调用；
   - 只有 `verify` 通过且 `actual_total_frames == expected_total_frames` 时才能标记 `complete`。
9. base index 完整后，执行：
   - 需要时建立 1s hotspot 缓存；
   - 按有限时间窗口生成并检查 contact sheets；
   - 建立 `source-atoms.jsonl`；
   - text-side + visual-side orphan review；
   - 建立 `events.jsonl`；
   - 建立 `slide-coverage.jsonl`；
   - 从原视频选择代表帧；
   - **最终视觉资产直接保存完整视频 frame，不做 crop / semantic ROI / resize / scale / pad**；
   - 按 `content_domain` 或本讲实际内容执行 domain-aware completeness review；
   - 写 draft；
   - source atom obligation check；
   - visual coverage check；
   - dynamic state-chain review；
   - evaluation-only 对照；
   - targeted repair；
   - reader-facing sanitation；
   - full-frame asset mechanical check。
10. 字幕证据按 v4.9.4 policy：ASR / unknown subtitle 中的数字、公式、单位、专名、命令、identifier、否定词、条件词和关键结论必须在存在疑点时回原视频、硬字幕或官方材料交叉核验。硬字幕是独立证据，不是无条件权威。
11. 纯文字 slide 必须转成结构化 Markdown；同时默认保留该独立 slide 出现时的一张完整视频帧，除非明确属于重复页或无教学信息。
12. live terminal / IDE / UI / board 按关键 state chain 选图，不按固定秒数堆图；每张最终图仍必须是完整视频帧。
13. `slide-coverage.jsonl` 中所有 `decision=retain` 的 asset 必须实际保留在最终 `assets/coverage/`。正文可以只引用其中有阅读价值的子集。
14. 若官方 chapter/schedule 页面明确关联本讲 paper / assigned reading / required reading：
   - 可完整下载的 PDF 放入 `papers/`；
   - 主 Markdown 顶部提供相对链接；
   - 不因为打包了论文就自动把论文内容并入课堂正文。
15. 根据官方编号空间生成 `artifact_basename`：
   - 默认：`<chapter-index>-<chapter-title>`；
   - 本地编号与官方编号不同或官方编号有 gap：`<chapter-index>-<official-unit-label>-<official-unit-number>-<official-title>`。
16. ZIP、解压目录和主 Markdown 统一 basename：

```text
<artifact_basename>.zip
<artifact_basename>/<artifact_basename>.md
```

17. 主 Markdown 顶部必须记录：
   - `workflow.name: ChatGPT-Web-Course-Note-Workflow`；
   - `workflow.version: v4.9.4`；
   - 可确认的 course / chapter / official unit / provenance 字段。
18. 最终 Markdown 禁止 HTML comments、内部 anchor 和 audit ID。出现 `<!-- episode:E01 -->`、其他 `<!-- ... -->`、`<a id=...>` 或内部字段时直接 FAIL。
19. 完整正式重跑最多 **2 轮**。base-index segment build/resume/repair 属于 cache preparation，不计入正式重跑次数。
20. 最终至少运行：

```bash
python course_note_checks.py "$NOTES" \
  --source-video "$VIDEO" \
  --coverage-dir "$PACKAGE_ROOT/assets/coverage" \
  --coverage-ledger "$PACKAGE_ROOT/audit/slide-coverage.jsonl" \
  --expected-workflow-version v4.9.4 \
  --artifact-basename "$ARTIFACT_BASENAME"
```

21. Final Package Gate 还必须确认：
   - chapter identity confirmed；
   - required sources 完整；
   - base-index complete；
   - source atom / semantic / visual obligations PASS；
   - retained coverage assets 全部在 package；
   - chapter-level paper/reading 已按 contract 处理；
   - ZIP 可列出并完整解压；
   - ZIP SHA-256 已计算。
22. 最终报告给出：
   - 章节身份与 local -> official mapping；
   - mechanical/package checks；
   - base-index completeness；
   - source atom / semantic / visual coverage；
   - full-frame asset check；
   - reader-facing sanitation；
   - 实际问题和未验证范围；
   - ZIP 下载链接与 SHA-256。

## v4.9.4 重点防止的退化

- 把 `top_k=100` 的 100/100 返回误判成目录总共只有 100 项；
- 大目录首批 listing 漏掉用户点名的 exact target 后，过早采用同 Lecture 的其他副本；
- connector 全局搜索 miss 后误判 required source 不存在，而实际文件可通过 course-root 完整目录枚举定位；
- 数学课遗漏公式/推导/例题/几何解释等实际出现的核心教学信息；
- 计算机课遗漏代码/命令/live output/error-recovery/实验结果等实际出现的核心教学信息；
- profile 中的 numbering override 未经官方 index 复核就被当成事实；
- 文件名看似正确，但视频实际属于另一 Lecture；
- 连续本地编号被误当成官方 Lecture 编号；
- SRT 与视频属于不同章节；
- multipart archive 缺卷却继续生成；
- connector 返回截断 source 仍继续处理；
- ASR 中公式、数字、否定关系未经核查直接进入正文；
- 其他学期官方材料被写成“本讲内容”；
- retained coverage asset 因未被 Markdown 引用而被 package 删除；
- chapter-level paper 明确存在却静默漏包；
- ZIP、目录、Markdown 使用互相不一致的章节命名；
- workflow 版本没有进入最终笔记；
- v4.9.1 已修复的 partial base index、HTML audit marker、截图裁剪问题再次出现。

最终回复保持简洁：结果、实际问题、笔记概述、workflow observation（仅在确有价值时）、ZIP 下载链接与 SHA-256。
