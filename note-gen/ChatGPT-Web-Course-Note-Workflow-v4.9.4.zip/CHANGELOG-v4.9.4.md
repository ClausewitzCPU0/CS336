# v4.9.4

修改基线：v4.9.3。

v4.9.4 是一次小范围 input-discovery contract 修订。它不修改 v4.9.3 已稳定的 Chapter Identity Preflight、domain-aware completeness、numbering mapping overrides、可恢复 2 秒 base index、Text-First、visual coverage ledger、full-frame capture、reader-facing sanitation、paper packaging 和 artifact basename 机制。

## 改进动机

SICP Lecture 1B 的真实生成任务暴露了一个边界条件：course root 实际包含 108 个直接子项，但首次 `list_folder(top_k=100)` 恰好只返回 100 项。用户明确指定的 `[P02]Lec1b：计算过程.mp4` 和 `.xml` 位于首批结果之外，而 `[P22]Lec1b：计算过程（外挂字幕）.mp4` 已经出现在首批结果中。

执行过程因此一度把“100/100 返回”误解为 connector 的 100 项硬限制，并在确认同 Lecture 内容一致后使用了 P22 视频作为替代。随后把相同目录调用提高到 `top_k=300`，实际返回 108 项，并同时找到精确的 P02 `.mp4/.srt/.xml` 三件套。这说明：

- 单次 listing 的返回上限不等于目录总量；
- `returned_count == requested_limit` 应视为可能截断；
- exact target 尚未完成完整目录查找时，不应因为看见同 Lecture 副本就提前替代；
- 对已知 course root，目录枚举比不稳定的全局 filename search 更适合作为 required input 的最终存在性判断。

v4.9.4 将这些经验固化为通用规则。

## 核心变化

1. 新增 **directory enumeration completeness**：
   - 不把默认 `top_k` 或单次返回数量当作目录硬上限；
   - 若 `returned_count == requested_limit`，标记 `possibly_truncated`；
   - connector 支持分页时持续翻页；只支持可调 limit 时提高上限并重新枚举；
   - 只有 `returned_count < requested_limit`、明确 no-next-page，或其他工具证据确认完整时，才能把 listing 当成完整目录视图。
2. 为当前 ChatGPT Web Google Drive connector 增加执行建议：course root 枚举从 `top_k=300` 起步；仍恰好命中上限则继续提高。已实测 108-item SICP 目录可完整返回。
3. 新增 **exact-file precedence**：用户明确给出的 basename 必须先经过完整查找；在此之前不得使用同 Lecture、同标题或外挂字幕版本替代。
4. 大目录 listing 结果应在工具编排层立即按 exact basename、章节标识和文件类型过滤，只把候选项送入后续上下文。
5. 替代 source 只有在 exact target 确认缺失/不可用且用户意图允许时才可采用，并必须记录 provenance。
6. Validator 与 base-index manifest 默认 workflow version 更新为 `v4.9.4`。

## 保留自 v4.9.3

- domain-aware completeness；
- global search miss -> course-root directory enumeration fallback；
- `content_domain`；
- `numbering.mapping_overrides`；
- Chapter Identity Preflight 与 official mapping 核验；
- direct file / chapter ZIP / multipart ZIP contract；
- required source 不完整时 fail fast；
- 字幕 provenance 与 ASR 高风险字段交叉核验；
- official material discovery；
- 2 秒 base index 完整性与恢复机制；
- source atoms / events / slide coverage ledger；
- Text-First；
- full-frame capture；
- retained coverage assets 必须留在 ZIP；
- chapter-level paper/reading packaging；
- reader-facing sanitation；
- ZIP / 顶层目录 / 主 Markdown 共用 `artifact_basename`；
- 最终 ZIP SHA-256。

## 兼容性

不新增 `course-profile.yaml` 字段，`schema_version` 保持为 1。v4.9.3 profile 可直接使用。
