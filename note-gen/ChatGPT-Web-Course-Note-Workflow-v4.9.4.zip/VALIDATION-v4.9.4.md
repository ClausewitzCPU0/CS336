# v4.9.4 发布验证范围

基线：v4.9.3。

本版只修改 input discovery contract，同时确认 v4.9.3 的 identity、domain completeness、base-index、full-frame 与 package 机制没有退化。

## 回归 A：大目录 listing 不能把请求上限当成目录总量

真实 fixture：SICP course root。

- 实际直接子项：108；
- `list_folder(top_k=100)`：返回 100；
- 首批结果中能看到 `[P22]Lec1b：计算过程（外挂字幕）.mp4`，但没有精确的 P02 `.mp4/.xml`；
- `list_folder(top_k=300)`：返回 108；
- 此时同时发现：
  - `[P02]Lec1b：计算过程.mp4`；
  - `[P02]Lec1b：计算过程.srt`；
  - `[P02]Lec1b：计算过程.xml`。

v4.9.4 预期：

1. `100/100` 必须判定为 `possibly_truncated`，不得宣称目录只有 100 项；
2. 提高 limit 或分页后继续；
3. `108/300` 可作为当前 connector 已完整返回该目录的证据之一；
4. 只有完整枚举后仍找不到 required target 才能判定缺失。

## 回归 B：exact target 优先于同 Lecture 副本

场景：required input 明确指定 P02，同时目录中存在 P22 同 Lecture 外挂字幕版。

预期：

- 在 P02 经过完整目录查找前不得选择 P22；
- 找到 P02 后必须直接使用 P02；
- 只有 P02 确认不存在/不可读取且用户意图允许替代时，才能选择 P22，并记录 source substitution；
- “视频主题一致”只能证明章节身份，不足以取消 exact-file precedence。

## 回归 C：search miss 仍需 directory fallback

保留 v4.9.3 行为：connector 的 filename/full-text search 对方括号、中文标题或短关键词返回空时，若 course root 已知，必须进入目录枚举；search miss 不能直接转换为 `required source missing`。

## 保留回归：domain-aware completeness 与 numbering mapping override

- 数学/计算机 domain obligations 保持 v4.9.3；
- `numbering.mapping_overrides` 仍只是候选提示，必须用官方 schedule/video index 复核；
- MIT 18.01 P10 错章 preflight 回归保持；
- final coverage asset 仍必须与 source frame 等尺寸，禁止 crop / resize / scale / pad。

## 机械检查

使用 synthetic fixture 验证：

1. `python -m py_compile build_video_index.py course_note_checks.py` -> PASS；
2. 正确 workflow metadata `v4.9.4` -> PASS；
3. 错误 workflow metadata -> FAIL；
4. artifact basename 一致 -> PASS；
5. retained coverage asset 存在且 `capture_mode=full_frame` -> PASS；
6. retained asset 缺失 -> FAIL；
7. cropped asset -> FAIL；
8. HTML comment / internal anchor / audit field -> FAIL；
9. `build_video_index.py` manifest 写入 `workflow_version: v4.9.4`；
10. versioned Markdown 内部引用不存在旧的 v4.9.3 文件名；
11. Input/Runner 静态 contract 同时包含 `returned_count == requested_limit`、`possibly_truncated`、`top_k=300` 与 exact-file precedence。

## 不能由 checker 自动证明的部分

- connector 是否对某个账号/目录返回了所有有权限项目；
- 目录项是否语义上属于正确章节；
- exact target 与副本之间的内容差异；
- domain-aware completeness 是否语义完整；
- mapping override 是否与官方课程真实编号一致；
- source atoms 是否覆盖所有重要课堂信息。

这些仍需按 Runner / Input & Packaging / Production 的 evidence-based review 执行。

## 本次发布实测

真实 Google Drive connector 验证：

- SICP course root：`top_k=100` 返回 `100` 项；
- 同一目录：`top_k=300` 返回 `108` 项；
- 扩大枚举后成功定位用户点名的 P02 `.mp4/.srt/.xml`；
- 证明本次故障来自请求上限截断，而不是目录存在 100 项硬限制。

本地 synthetic fixture 验证：

- `python -m py_compile build_video_index.py course_note_checks.py`：PASS；
- 正确 `v4.9.4` metadata + artifact basename + retained ledger + `320x240` full-frame asset：PASS；
- metadata 改为 `v4.9.3`：按预期 FAIL；
- coverage asset 裁成 `320x200`：按预期 FAIL；
- `build_video_index.py` smoke test：完成 `1/1` segment、`1/1` expected frame；
- `--verify-only`：PASS；
- base-index manifest 写入 `workflow_version: v4.9.4`：PASS；
- v4.9.4 input-discovery 静态 contract：`returned_count == requested_limit`、`possibly_truncated`、`top_k=300`、exact-file precedence 全部存在：PASS。

这些测试验证机械与 contract 一致性，不把 synthetic fixture 当成 semantic coverage 证据。
