# Course Note Production v4.9.4

目标是生成**尽量可以替代原视频回看**的图文 Markdown 笔记。v4.9.4 以 v4.9.3 为稳定基线，保留既有可恢复 2 秒 base index，并继续使用三层冗余：

1. **source-complete text track**：尽可能完整、可搜索地记录课堂论证、例子、prompt、命令、错误、live output、数字、公式与教师结论；
2. **source atom obligation**：在 Writer 前冻结具体 source atoms，并检查它们是否进入最终 Markdown；
3. **visual completeness fallback**：即使语义 discovery 仍漏掉某个细节，也尽量通过完整视频帧截图和关键 live-state 截图保存原始课堂信息。

v4.9.4 不追求逐帧截图。它追求的是：**每个独立课件页、重要增量状态、板书阶段和关键 live state，都有可追溯的代表视觉证据；每张最终视觉资产都保持原视频完整 frame，不再裁剪。**

source-native hierarchy、来源忠实、可重建性和 reader-facing 可读性优先。人工整理稿和历史生成稿只能用于 evaluation-only。
> **v4.9.4 继承说明：** v4.9.3 已稳定包含 Chapter Identity Preflight、domain-aware completeness、directory enumeration fallback、numbering mapping overrides、可恢复 2 秒 base index、full-frame capture 与 package contract。v4.9.4 不改变 production/visual 算法，只补强大目录枚举完整性与 exact-file precedence。


## 1. 来源与能力边界

正式 generation 前先遵循 `Course-Note-Input-and-Packaging-v4.9.4.md`：发现 direct files / chapter ZIP / multipart archive，完成 Chapter Identity Preflight，再冻结来源。章节身份未确认时不得构建全程 base index。

对实际归档输入列成员、大小、CRC、SHA-256，识别正式视频、字幕、课件、教材、仓库和参考网页。重复上传后缀不决定版本，内部文件与 manifest 才决定版本。

`audit/sources.json` 是 generation allowlist。人工整理稿、历史生成物、个人学习记录只能进入 evaluation-only 清单，不得进入 generation allowlist。

字幕必须标注来源角色：`official_transcript / human_subtitle / asr_subtitle / unknown_subtitle / hard_subtitle`。`.srt` 扩展名本身不代表可信度。ASR / unknown subtitle 中的数字、日期、单位、公式、专名、API/命令/identifier、否定词、条件词和关键结论存在疑点时，必须回原视频、硬字幕或正式材料交叉核查。硬字幕是独立交叉证据，不是无条件权威。XML / 弹幕 / 评论仅作待核查线索。

术语修正必须能由画面、上下文或正式资料支撑。没有执行的代码、没有看到的终态、没有听过的音频，都不能声称验证过。编辑性补充必须显式标注。

### 1.1 Domain-aware completeness

在不改变 source fidelity 的前提下，根据课程和本讲实际内容补强 completeness obligation。`course-profile.yaml` 可提供 `content_domain` hint；若为 `auto` 或缺失，则根据本讲实际 source 判断。domain 只决定“重点检查哪些信息是否遗漏”，**不能成为扩写源中未出现内容的理由**。

数学课程优先检查：

- 定义、定理、命题及其适用条件；
- 公式、符号、矩阵/向量元素、等式与不等式关系；
- 推导、证明思路和关键中间步骤；
- 例题、反例、计算过程；
- 几何解释、图形关系和板书阶段；
- 教师强调的假设、边界条件、例外和结论。

计算机课程优先检查：

- 算法、数据结构、协议、系统组件与设计关系；
- 代码、prompt、命令、API、identifier 和配置；
- 输入、关键中间状态、live output 与最终结果；
- error/failure、recovery/fallback 和 before/after；
- 实验设置、测量值、性能结果和实现限制；
- 教师解释的实现细节、工程权衡和边界条件。

混合课程同时应用相关义务。若某类内容在本讲没有出现，不得为了满足 checklist 人工补齐。

## 2. 视频缓存与 discovery

全程 **2 秒 base index** 仍是 visual discovery 的机械底座；动态热点按 **1 秒**补充。v4.9.4 不降低 sampling coverage，而是把 base index 改成**可恢复、分段、可验证的 cache**。详细 contract 见 `Video-Index-Cache-v4.9.4.md`。

ChatGPT Web 默认执行参数：

- `interval=2s`；
- `segment=90s`；
- `workers=min(4, max(1, cpu_count-1))`；
- 多 worker 时每个 FFmpeg `-threads 1`；
- 单次工具调用最多处理一个 worker batch；
- segment 必须独立验证并写 completion record；
- 中断后只恢复 pending / damaged segment。

> **继承自 v4.9/v4.9.1：** 可恢复 2 秒 base index 的执行策略保持不变。

### 2.1 Base-index completeness gate

对视频时长 `D`：

```text
expected_total_frames = ceil(D / 2)
```

只有以下条件全部成立，才允许 `base_index_status=complete`：

1. manifest 绑定当前 source；
2. 每个 segment 都有合法 completion record；
3. 每个 segment 的 actual frame count 等于 expected frame count；
4. `actual_total_frames == expected_total_frames`；
5. 未发现缺帧、损坏帧或跨 segment 的参数不一致。

只要 base index 不完整，不能用稀疏周期采样、局部 hotspot 或“已看过若干关键区间”替代后直接进入 Final Gate。

> **继承自 v4.9/v4.9.1：** partial cache 仍必须用 expected/actual 机械核算，不能凭目录存在判断完整。

### 2.2 Contact sheet 全时间轴检查

base cache 完整后，再按有限窗口检查 contact sheets。默认每张最多覆盖 180 秒，也就是 90 个 2 秒缩略帧，可使用 10×9 布局。不要一次把整讲数千张帧拼成一个超大 contact sheet。

检查 contact sheet 只负责 state discovery；文字辨认、状态比较和 slide clustering 回到对应 base frame 或原分辨率 frame。最终视觉资产只允许从原视频直接导出完整 frame，不进行区域裁剪。prepared 与 inspected 必须分开。

> **继承自 v4.9/v4.9.1：** contact sheet 继续使用固定窗口，避免把完整时间轴一次拼成超大图。

v4.9.4 仍不把抽帧频率提高到全程 1 秒。新增可靠性来自**完整可验证的 2 秒时间轴缓存**与 distinct visual states 的保留策略，而不是把 dense cache 直接塞入最终 ZIP。

## 3. Source Atom Inventory

沿用 v4.8.1 的 `audit/source-atoms.jsonl`。Writer 开始前，从原始字幕、课件可见文字和实际查看的视频状态中冻结 source atoms。

典型 atom 类型：

- `anecdote_key`
- `exact_prompt`
- `command_or_identifier`
- `error_text`
- `live_output`
- `quantitative_claim`
- `formula`
- `example_key`
- `teacher_conclusion`
- `state_transition`
- `slide_structure`

最低字段：

- `atom_id`
- `time_range` 或 source anchor
- `source_id`
- `atom_type`
- `provenance_role`
- `source_state_id`
- `raw_or_visible_text`
- `normalized_text`
- `obligation_mode`: `exact / normalized / structured / semantic`
- `required`
- `reason`
- `mapped_episode_ids`
- `final_note_destination`
- `verification_status`

exact prompt、关键 live output、错误文本、关键命令/identifier、数字和公式默认 `required=true`。

## 4. Episode 与 provenance/state separation

再建立 `audit/events.jsonl`。以下边界出现时必须拆 episode：

- 新 anecdote；
- exact prompt；
- live input / intermediate / output；
- failure / recovery；
- quantitative claim；
- formula；
- comparison 对象变化；
- teacher conclusion；
- original slide ↔ slide AI expansion；
- live result ↔ slide recap；
- provenance role 或 source state 变化。

来源角色与 episode kind 必须相容：

- `live_output` 不得标为 `slide_ai_expansion`；
- `slide_example` 不得冒充现场执行结果；
- failure / recovery 必须对应不同 source state；
- 教师口述、screen AI output、课件 AI 扩写和编辑性说明必须区分。

## 5. Text-First：仍然要求完整 Markdown 转写

### 5.1 纯文字 slide

纯文字 slide 必须高保真转成 Markdown，保留：

- 标题层级；
- unordered / ordered list 与嵌套；
- blockquote；
- 表格；
- 行内代码与代码块；
- 行内公式 `$...$`；
- 块公式 `$$...$$`；
- 必要的粗体、斜体和强调。

**沿用 Text-First 的关键规则：**纯文字 slide 被完整转成 Markdown 后，默认仍保留一张该独立 slide 出现时的完整视频帧，作为 visual completeness fallback。只有在明确属于重复页/重复 build、无新增教学信息时才可不保留。

### 5.2 图片中的文字仍必须可搜索

截图不能成为以下内容的唯一载体：

- exact prompt；
- terminal error；
- live output；
- 公式；
- 数字与关键 claim；
- 核心列表或定义。

即使截图保留，这些内容仍必须进入正文 Markdown。

## 6. Slide Coverage Ledger：完整课件视觉兜底

新增 `audit/slide-coverage.jsonl`。目标不是统计图片数量，而是核算视频中的**独立课件视觉状态**是否有去向。

每条至少包含：

- `slide_id`
- `time_range`
- `source_frame`
- `visual_kind`: `slide / slide_build / board / split_slide_board / browser / terminal / ide / demo / other`
- `distinctness_reason`
- `capture_mode`: 固定为 `full_frame`
- `source_frame_size`: `[width, height]`
- `asset_frame_size`: `[width, height]`
- `complete_content_visible`: `true / false`
- `markdown_transcribed`: `true / false / not_applicable`
- `decision`: `retain / merge_duplicate / omit_noninstructional`
- `merge_target`
- `asset_path`
- `omission_reason`
- `review_status`

### 6.1 默认保留规则

对于 lecture-style 视频：

- 每个独立 slide/page 默认 `retain`；
- 同一页仅有讲师移动、鼠标移动、轻微摄像机变化时合并为一个代表帧；
- 增量 reveal/build 只有在新增内容有独立教学意义时才单独保留；
- 同一 slide 在多个时间点重复出现，通常只保留最完整、最清晰的一张，除非不同讲述阶段需要区分来源状态；
- 页面切换过渡帧、模糊帧、遮挡严重帧不保留。

### 6.2 v4.9.4 继承的完整视频帧规则

v4.9.4 继续不定义“完整教学内容区域”，而是把最终视觉资产定义为**完整视频 frame**：

- 从选定时间点直接导出原视频 frame；
- 不使用 `crop`、ROI、语义分区、黑板边界识别、slide 边界识别或人物避让来改变图像范围；
- 不为了去掉内嵌字幕、播放器边缘、空白区、讲师或观众而裁剪；
- 不缩放、不 padding；最终资产宽高应与源视频 frame 一致；
- 若讲师、字幕或运动模糊遮挡关键信息，优先改选同一状态附近的完整帧，必要时多保留一张完整帧；
- 若原视频本身没有同时拍到完整教学内容，workflow 不得通过拼接或推断补出画面，改用 Markdown 转写说明。

候选帧选择仍然可以智能化；**图像几何处理不再智能化**。这样把“选哪一帧”和“截哪一块”分离，避免区域识别错误永久删除课堂信息。

## 7. Live Demo / Terminal / IDE / Board

静态课件采用 slide coverage；动态过程采用 state-chain coverage。

以下状态优先保留：

- setup / input；
- 第一次关键失败；
- recovery/fallback；
- decisive intermediate；
- final result；
- before/after comparison。

同一动态 episode 不按时间间隔机械截图，只保留理解过程所需的最小状态链。若 live output 本身是重要文字，必须同步转成 Markdown。

## 8. Visual Dedup：减少重复，不减少覆盖

允许基于以下信息合并视觉重复：

- perceptual similarity；
- slide 标题与主要文本一致；
- 完整 frame 的主要可见状态一致；
- source state 无新增教学信息。

不得仅因为两张图“看起来很像”就合并不同的 failure/recovery、before/after、原始 slide/AI 扩写或 live result/slide recap。

目标是：**一页一代表状态，而不是一页多张；一个动态过程保留关键状态，而不是每 2 秒一张。**

## 9. Full-frame capture 质量

最终图片必须满足：

- `capture_mode=full_frame`；
- 直接从原视频选定时间点导出，不使用 crop filter；
- 不对最终资产执行 resize / scale / pad；
- `asset_frame_size == source_frame_size`；
- 图片可正常解码；
- 同一语义状态优先选文字最清晰、遮挡最少的完整帧；
- 关键信息仍必须进入 searchable Markdown，不能依赖截图独占。

推荐的直接抽帧形式：

```bash
ffmpeg -hide_banner -loglevel error -ss "$TS" -i "$VIDEO" \
  -frames:v 1 -q:v 2 "$OUT"
```

命令不得附加 `crop`、`scale`、`pad` 或内容感知图像 filter。JPEG 编码本身允许，但不能改变 frame 几何尺寸。

最终验收使用 `course_note_checks.py --source-video ... --coverage-dir ...` 机械核对所有 coverage asset 的尺寸。尺寸不一致即 FAIL。

> **继承自 v4.9.1：** full-frame 规则继续作为确定性的视觉几何 Final Gate。

## 10. Final Reader-Facing Sanitation：内部标记不得进入正文

最终主 Markdown（`<artifact_basename>.md`）是读者文档，不是 audit transport。

**严禁出现：**

- `<!-- episode:E01 -->` 或任何 `<!-- ... -->` HTML comment；
- `<a id="..."></a>` 等内部定位锚点；
- `episode_id`、`atom_id`、`source_state_id`、`action_id` 等内部字段；
- 内部工作目录、绝对路径、cache path；
- 为 checker 服务但对读者无意义的标签。

所有审计关系只能存放在 `audit/` 文件中。最终打包前必须执行 reader-facing sanitation pass：

1. 搜索 `<!--` 与 `-->`，任何命中都 FAIL；
2. 搜索 `<a id=`，任何命中都 FAIL；
3. 搜索内部 ID 格式和绝对工作路径；
4. 检查图片引用、数学 delimiter、代码 fence；
5. 清理后重新检查主 Markdown，禁止“先生成再把隐藏标记留在 Markdown 源码里”。

## 11. Obligation Gate

protected episode 只有在以下条件同时满足时才能 `covered`：

1. required source atoms 已映射；
2. atom 的目标 section 存在；
3. exact/normalized 内容实际出现在对应 section；
4. structured atom 的结构已保留；
5. semantic atom 保留辨识性细节；
6. 重要图片文字已有 searchable Markdown；
7. 对 lecture-style 课程，对应 distinct slide state 已在 `slide-coverage.jsonl` 中 `retain` 或有合法 merge/omit 理由。

不得仅依据 `events.jsonl.status=covered` 或模型自评 PASS。

## 12. evaluation-only 人工稿

人工稿只能在 draft、source atoms、events 与 slide coverage ledger 都冻结后用于 evaluation-only：

- 查明显漏项；
- 查独立 slide 是否缺图；
- 查关键动态状态是否不足；
- 查 detail level 是否明显低于课程本身。

发现差异后必须回原视频/字幕/课件确认。不得直接从人工稿复制内容作为 source evidence。

## 13. 资源预算

保持：

- 全程 2 秒 base index + 局部 1 秒 hotspot；
- base cache 对同一 source/参数组合只构建一次，后续优先 resume / repair；
- 一个工具调用只处理一个受限 worker batch；
- 完整正式重跑最多 2 轮；
- base-index segment build / resume / repair **不计入**正式重跑次数；
- 局部漏项、代表帧替换、Markdown 转写使用 targeted repair；最终资产不做裁剪 repair。

若默认 `90s × up to 4 workers × 1 thread` 仍接近执行时限，先把 segment 缩短到 60 秒，再到 30 秒；**不得扩大 2 秒 interval 来换性能**。

> **继承自 v4.9/v4.9.1：** 性能问题继续通过缩小单个执行单元解决，而不是降低 discovery coverage；cache preparation 不消耗语义重跑预算。

最终图片数量不得反向驱动 discovery，也不设硬性配额。v4.9.4 保留的仍是 distinct slide representatives 和关键动态状态，不是 base cache 本身。

`slide-coverage.jsonl` 中所有 `decision=retain` 的资产必须留在最终 package 的 `assets/coverage/`。是否在主 Markdown 中实际引用由 reader-facing usefulness 决定；未被正文引用不能成为删除 retained coverage asset 的理由。

## 14. 最终验收与 package contract

最终主 Markdown 必须遵循 `Course-Note-Input-and-Packaging-v4.9.4.md` 的 metadata 与 artifact naming contract；workflow name/version 必须可机器搜索。若官方 chapter 页面明确关联本讲 paper / assigned reading / required reading，则按 contract 处理 `papers/`。

最终报告分别给出：

- package / mechanical checks；
- base-index completeness：expected / actual frames、completed / total segments、interval / segment；
- source atom obligation coverage；
- semantic coverage judgment；
- slide visual coverage：distinct / retained / merged / omitted；
- dynamic state-chain coverage；
- full-frame asset check：source frame size、asset count、mismatch count；
- reader-facing sanitation result；
- 未验证范围。

只要 chapter identity 未确认、required source 不完整、base index 未机械验证为 complete、正文仍包含内部审计 comment、存在无去向的独立 slide state、任一 retained coverage asset 缺失、任一最终 coverage asset 不是完整视频 frame，或 workflow 元信息缺失，Final Gate 不得 PASS。
