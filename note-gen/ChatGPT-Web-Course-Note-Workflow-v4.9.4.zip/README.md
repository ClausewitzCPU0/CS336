# ChatGPT Web Course Note Workflow v4.9.4

从 `Course-Note-Runner-v4.9.4.md` 开始。

v4.9.4 以 v4.9.3 为稳定基线。Chapter Identity Preflight、可恢复 2 秒 base index、source atoms、events、visual coverage ledger、Text-First、domain-aware completeness、numbering mapping overrides、reader-facing sanitation、full-frame capture 和 package contract 全部保留。

本版只补强一件事：**大目录中的 required input discovery 必须可证明地完整，且用户点名的精确文件优先级高于同章节副本。**

## 为什么需要 v4.9.4

在 SICP Lecture 1B 的真实任务中，course root 实际有 108 个直接子项。首次目录枚举使用 `top_k=100`，因此结果刚好返回 100 项，并漏掉了用户明确指定的 `[P02]Lec1b：计算过程.mp4` 与 `.xml`；同目录中的 `[P22]Lec1b：计算过程（外挂字幕）.mp4` 却已经可见，导致执行过程误以为目标目录存在 100 项硬限制，并采用了不必要的同 Lecture 替代视频。

随后把同一 `list_folder` 调用提高到 `top_k=300`，一次返回 108 项，精确的 P02 `.mp4/.srt/.xml` 三件套全部出现。由此确认：**默认/当前请求上限不能被解释为目录总量；返回数量恰好等于请求上限时必须怀疑截断。**

v4.9.4 把这个经验写成通用 contract，避免以后在课程大目录中再次发生“精确目标文件实际存在，但被首屏枚举截断，于是误用副本”的情况。

## v4.9.4 核心变化

- `Course-Note-Input-and-Packaging-v4.9.4.md` 新增 **bounded directory enumeration completeness**：
  - 不得把默认 `top_k=100` 或任何单次返回上限当成目录硬上限；
  - 若 `returned_count == requested_limit`，视为 `possibly_truncated`，必须分页或提高枚举上限后继续；
  - 对当前 Google Drive connector，已验证 `list_folder(top_k=300)` 可以返回超过 100 个直接子项；推荐从 300 开始，必要时继续提高，而不是固定停在 100；
  - 用户明确给出 basename 时，必须先穷尽查找 exact basename，再考虑同 Lecture/同标题副本；
  - 枚举结果应在工具调用后立即按章节标识、精确 basename 和文件类型过滤，避免把大目录完整列表灌入上下文。
- Runner 将“大目录完整枚举 + exact-file precedence”前置到 Chapter Identity Preflight 之前。
- Validation 新增 SICP 108-item course-root 回归案例和 duplicate-substitution 回归。
- v4.9.3 的 domain-aware completeness、directory search fallback、mapping overrides 与其余稳定机制保持不变。

## 推荐最小调用

当 course root 中已经有 `course-profile.yaml` 时，每章可以缩成：

```text
@Google-Drive

使用 ChatGPT-Web-Course-Note-Workflow-v4.9.4。

course root：
<Google Drive course root>

处理本地章节 <Pxx>，生成最终图文 Markdown 笔记并打包 ZIP。
```

如果尚未建立 course profile，只需在第一次任务里补充课程名称、官方课程入口和必要的学期/provenance 背景；这些信息不需要在后续每章重复。

## 文件说明

- `Course-Note-Runner-v4.9.4.md`：一次任务的执行顺序；
- `Course-Note-Production-v4.9.4.md`：正文生成与视觉覆盖 contract；
- `Course-Note-Input-and-Packaging-v4.9.4.md`：输入发现、章节身份、官方映射、论文与打包 contract；
- `Video-Index-Cache-v4.9.4.md`：可恢复 2 秒 base index contract；
- `course-profile.example.yaml`：课程级 reusable profile 模板；
- `Course-Note-Benchmark-Regressions-v1.md`：只读历史回归；
- `course_note_checks.py`：最终 reader-facing / full-frame / package 机械检查；
- `build_video_index.py`：可恢复 base-index 构建脚本；
- `VALIDATION-v4.9.4.md`：发布验证；
- `CHANGELOG-v4.9.4.md`：版本变更与改进动机。
