# Video Index Cache Contract v4.9.4

本 contract 的执行行为与 v4.9.3 相同；v4.9.4 不修改已验证的 base-index 构建算法。v4.9.4 的新增变化只发生在输入发现阶段的大目录枚举完整性与 exact-file precedence，不改变 base-index sampling / resume / verify 行为。

本文件定义全程 2 秒 base index 的执行 contract。它解决的是 **ChatGPT Web 外层执行时限与 FFmpeg 长时间解码任务不匹配**的问题，不改变 2 秒采样的语义覆盖目标。

## 1. 不可降低的目标

对一个时长为 `D` 秒的视频，base index 使用固定 `interval=2s`，完整索引的理论帧数为：

```text
expected_total_frames = ceil(D / 2)
```

只有机械验证确认所有 segment 完成，且总帧数与 manifest 一致时，base index 才是 `complete`。不能用“定期采样”“关键区间抽帧”或 1s hotspot 代替未完成的全程 2 秒 base index。

> **继承自 v4.9 的原因：** v4.8.2 的目标本来就是全时间轴 discovery。超时属于执行策略问题，不应通过降低覆盖率来规避，否则后续 slide clustering、orphan review 和视觉兜底会失去机械完整性基础。

## 2. 默认执行参数

ChatGPT Web 默认：

```text
interval_seconds      = 2
segment_seconds       = 90
workers               = min(4, max(1, cpu_count - 1))
threads_per_worker    = 1
max_segments_per_run  = workers
thumbnail_width       = 240
jpeg_qscale           = 7
```

`segment_seconds` 必须是 `interval_seconds` 的整数倍。

> **继承自 v4.9 的原因：** 在 5-core 容器的 1080p H.264 实测中，一个默认 FFmpeg 解码进程可使用约 3.5 个 CPU core；多个默认线程进程同时运行会过度争抢 CPU。发布验证中 120 秒 batch 在不同区间出现约 25–35 秒的波动，而 90 秒 batch 连续两组约 20–21 秒；因此默认收紧到 90 秒，以给外层工具时限留出更稳定的余量。

## 3. Runner 调用方式

首次和后续 batch 使用同一命令；每次命令处理一个 batch 后退出：

```bash
python build_video_index.py "$VIDEO" cache/base2s \
  --source-sha256 "$VIDEO_SHA256"
```

Runner 检查输出中的 `status`。若为 `pending`，在**新的工具调用**中再次执行同一命令；若为 `complete`，再执行一次机械验证：

```bash
python build_video_index.py "$VIDEO" cache/base2s \
  --source-sha256 "$VIDEO_SHA256" \
  --verify-only
```

若默认 90 秒 segment 对当前 codec 仍过慢，应在缓存构建早期改用新的 cache 目录并指定 60 秒：

```bash
python build_video_index.py "$VIDEO" cache/base2s-60 \
  --source-sha256 "$VIDEO_SHA256" \
  --segment-seconds 60
```

不要在同一次 shell 调用中写 `while status != complete` 循环。

> **继承自 v4.9 的原因：** segment size 是 cache manifest 的组成部分，运行中修改会改变 segment 边界。性能回退应切换到新 cache，而不是把不同分段参数混入同一 manifest。

## 4. 单次调用边界

一次 `build_video_index.py` 调用最多处理 `max_segments_per_run` 个 pending segment，处理完成后必须退出。若仍有 pending segment，由 Runner 发起下一次调用。

禁止把“反复调用直到全部完成”的 while-loop 包在同一个 shell / Python 外层调用里。

> **继承自 v4.9 的原因：** 内部分段不能消除外层工具调用时限。真正有效的边界必须位于工具调用之间。

## 5. Cache 结构

推荐目录：

```text
cache/
  base2s/
    manifest.json
    seg_0000/
      frame_0001.jpg
      ...
      .done.json
    seg_0001/
      ...
      .done.json
```

`manifest.json` 至少记录：

- source path / source size；
- source SHA-256（若来源冻结阶段已经计算）；
- video duration；
- interval；
- segment length；
- expected total frames；
- segment count；
- width / JPEG quality；
- completed segments / frames；
- cache completeness status。

`.done.json` 至少记录该 segment 的 start、duration、expected frames、actual frames 和生成参数。

> **继承自 v4.9 的原因：** 仅以“目录存在”或“有 JPG 文件”判断缓存完成会把超时留下的 partial cache 当成有效输入。显式 manifest + per-segment completion record 能机械地区分 complete、pending 与 damaged segment。

## 6. 原子完成与恢复

每个 segment 先写临时目录。只有 FFmpeg 正常退出并且帧数等于该 segment 的 expected frame count，才原子替换为正式 `seg_NNNN/` 并写 `.done.json`。

恢复时：

1. 保留已验证完成的 segment；
2. 忽略或删除没有合法 `.done.json` 的 partial segment；
3. 只重建 pending / damaged segment；
4. 不重新解码完整视频。

> **继承自 v4.9 的原因：** 超时和中断是预期故障模式。缓存必须把“中断后继续”当作正常路径，而不是异常情况下的手工补救。

## 7. FFmpeg 基线命令

语义等价于：

```bash
ffmpeg \
  -hide_banner \
  -loglevel error \
  -nostdin \
  -threads 1 \
  -ss "$START" \
  -i "$VIDEO" \
  -t "$SEGMENT_DURATION" \
  -map 0:v:0 \
  -an -sn -dn \
  -vf "setpts=PTS-STARTPTS,fps=1/2:start_time=0,scale=240:-2:flags=fast_bilinear" \
  -frames:v "$EXPECTED_FRAMES" \
  -q:v 7 \
  "$TEMP_DIR/frame_%04d.jpg"
```

base index 是 discovery 缩略图，不承担精细文字识别。需要辨认公式、代码、终端输出或小字时，按 timestamp 回原视频抽原分辨率帧。

> **继承自 v4.9 的原因：** 低分辨率 base frames 可显著降低解码后的写盘量和 contact-sheet 成本；将文字核验留给 targeted original-resolution extraction，不会牺牲 source fidelity。

## 8. 性能回退

默认 90 秒 segment 是基线，不是硬编码到所有 codec 的假设。若一个 worker batch 仍接近外层执行上限或发生超时：

1. 先保持 `interval=2s` 不变；
2. 把 `segment_seconds` 从 90 降到 60；仍过慢时再降到 30；
3. 保持 segment length 为 2 秒的整数倍；
4. 不通过减少全时间轴覆盖或扩大 interval 解决性能问题。

推荐软目标：一个 worker batch 的实际 wall time 控制在约 25 秒以内，并为外层工具留至少约 10 秒余量。

> **继承自 v4.9 的原因：** HEVC、AV1、4K、60fps 或异常 GOP 结构可能显著慢于本次 1080p H.264 样本。缩短 segment 比降低采样完整性更安全。

## 9. Contact sheet 分层

不得把完整 2 秒 cache 一次拼成一张巨大 contact sheet。默认每张 contact sheet 最多覆盖 2 个 90 秒 segment：

```text
source window: 180 s
frames:         90
layout:        10 x 9
```

检查顺序：

```text
2s base frames
  -> 4-minute contact sheet
  -> 发现 distinct state / hotspot
  -> 打开对应 base frame
  -> 必要时从原视频抽原分辨率 frame
```

> **继承自 v4.9 的原因：** 抽帧完成后，超大的 contact sheet 仍可能成为新的内存、渲染和视觉检查瓶颈。固定窗口可以保持全时间轴覆盖，同时让每次视觉检查规模有上界。

## 10. Audit 与重跑语义

base-index segment build / resume / repair 都属于 **cache preparation**，不计入“完整正式重跑最多 2 轮”。

最终 audit 至少报告：

```text
base_index_status
expected_total_frames
actual_total_frames
completed_segments
segment_count
interval_seconds
segment_seconds
```

只要 `base_index_status != complete`，Final Gate 默认 FAIL；若来源文件本身不可访问、损坏或不匹配，则按来源错误停止任务，而不是降级继续生成。
