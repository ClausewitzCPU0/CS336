#!/usr/bin/env python3
"""Resumable segmented video-index builder for Course Note Workflow v4.9.4.

The script deliberately processes at most one bounded segment batch per invocation.
Run it repeatedly until it prints status=complete, then use --verify-only as the
mechanical Final Gate check.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 1
MANIFEST_NAME = "manifest.json"
DONE_NAME = ".done.json"
EPS = 1e-9


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def run_checked(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def probe_duration(video: Path, ffprobe: str) -> float:
    cp = run_checked(
        [
            ffprobe,
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(video),
        ]
    )
    try:
        duration = float(cp.stdout.strip())
    except ValueError as exc:
        raise RuntimeError(f"ffprobe returned invalid duration: {cp.stdout!r}") from exc
    if not math.isfinite(duration) or duration <= 0:
        raise RuntimeError(f"invalid video duration: {duration!r}")
    return duration


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            block = f.read(8 * 1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def expected_frames(duration: float, interval: float) -> int:
    # Samples are anchored at segment-relative t=0, interval, 2*interval, ...
    return max(1, int(math.ceil((duration / interval) - EPS)))


def atomic_write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.write("\n")
        os.replace(tmp_name, path)
    finally:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass


@dataclass(frozen=True)
class Segment:
    index: int
    start: float
    duration: float
    expected: int

    @property
    def name(self) -> str:
        return f"seg_{self.index:04d}"


def make_segments(total_duration: float, segment_seconds: float, interval: float) -> list[Segment]:
    count = int(math.ceil((total_duration / segment_seconds) - EPS))
    segments: list[Segment] = []
    for i in range(count):
        start = i * segment_seconds
        duration = min(segment_seconds, total_duration - start)
        if duration <= EPS:
            continue
        segments.append(
            Segment(
                index=i,
                start=start,
                duration=duration,
                expected=expected_frames(duration, interval),
            )
        )
    return segments




def cleanup_stale_temp_dirs(root: Path) -> int:
    removed = 0
    for path in root.glob(".seg_*.????????"):
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
            removed += 1
    return removed

def frame_files(seg_dir: Path) -> list[Path]:
    return sorted(seg_dir.glob("frame_*.jpg"))


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def segment_valid(root: Path, seg: Segment, params: dict[str, Any]) -> tuple[bool, str]:
    seg_dir = root / seg.name
    done_path = seg_dir / DONE_NAME
    if not seg_dir.is_dir():
        return False, "missing segment directory"
    if not done_path.is_file():
        return False, "missing completion record"
    try:
        done = load_json(done_path)
    except Exception as exc:  # noqa: BLE001 - validation should report malformed JSON
        return False, f"invalid completion record: {exc}"

    checks = {
        "segment_index": seg.index,
        "start_seconds": seg.start,
        "duration_seconds": seg.duration,
        "expected_frames": seg.expected,
        "interval_seconds": params["interval_seconds"],
        "width": params["width"],
        "jpeg_qscale": params["jpeg_qscale"],
        "threads_per_worker": params["threads_per_worker"],
    }
    for key, expected in checks.items():
        actual = done.get(key)
        if isinstance(expected, float):
            if actual is None or abs(float(actual) - expected) > 1e-6:
                return False, f"completion record mismatch for {key}: {actual!r} != {expected!r}"
        elif actual != expected:
            return False, f"completion record mismatch for {key}: {actual!r} != {expected!r}"

    frames = frame_files(seg_dir)
    if len(frames) != seg.expected:
        return False, f"frame count {len(frames)} != expected {seg.expected}"
    if done.get("actual_frames") != len(frames):
        return False, "actual_frames in completion record does not match files"
    if any(p.stat().st_size <= 0 for p in frames):
        return False, "zero-length frame found"
    return True, "ok"


def make_manifest(
    video: Path,
    duration: float,
    interval: float,
    segment_seconds: float,
    width: int,
    jpeg_qscale: int,
    threads_per_worker: int,
    source_sha256: str | None,
) -> dict[str, Any]:
    segments = make_segments(duration, segment_seconds, interval)
    return {
        "schema_version": SCHEMA_VERSION,
        "workflow_version": "v4.9.4",
        "created_at": utc_now(),
        "updated_at": utc_now(),
        "source": {
            "name": video.name,
            "size_bytes": video.stat().st_size,
            "sha256": source_sha256,
            "duration_seconds": duration,
        },
        "params": {
            "interval_seconds": interval,
            "segment_seconds": segment_seconds,
            "width": width,
            "jpeg_qscale": jpeg_qscale,
            "threads_per_worker": threads_per_worker,
        },
        "expected_total_frames": expected_frames(duration, interval),
        "segment_count": len(segments),
        "completed_segments": 0,
        "actual_total_frames": 0,
        "base_index_status": "pending",
        "segments": [
            {
                "index": s.index,
                "start_seconds": s.start,
                "duration_seconds": s.duration,
                "expected_frames": s.expected,
            }
            for s in segments
        ],
    }


def validate_manifest(
    manifest: dict[str, Any],
    video: Path,
    duration: float,
    interval: float,
    segment_seconds: float,
    width: int,
    jpeg_qscale: int,
    threads_per_worker: int,
    source_sha256: str | None,
) -> None:
    if manifest.get("schema_version") != SCHEMA_VERSION:
        raise RuntimeError("manifest schema_version mismatch")
    src = manifest.get("source", {})
    if src.get("size_bytes") != video.stat().st_size:
        raise RuntimeError("source size differs from manifest; use a new cache directory")
    if abs(float(src.get("duration_seconds", -1)) - duration) > 0.01:
        raise RuntimeError("source duration differs from manifest; use a new cache directory")
    old_sha = src.get("sha256")
    if old_sha and source_sha256 and old_sha.lower() != source_sha256.lower():
        raise RuntimeError("source SHA-256 differs from manifest; use a new cache directory")

    params = manifest.get("params", {})
    wanted = {
        "interval_seconds": interval,
        "segment_seconds": segment_seconds,
        "width": width,
        "jpeg_qscale": jpeg_qscale,
        "threads_per_worker": threads_per_worker,
    }
    for key, value in wanted.items():
        old = params.get(key)
        if isinstance(value, float):
            if old is None or abs(float(old) - value) > 1e-9:
                raise RuntimeError(f"cache parameter changed: {key}={old!r}, requested {value!r}")
        elif old != value:
            raise RuntimeError(f"cache parameter changed: {key}={old!r}, requested {value!r}")


def refresh_manifest(root: Path, manifest: dict[str, Any]) -> tuple[list[Segment], list[tuple[Segment, str]]]:
    p = manifest["params"]
    segments = [
        Segment(
            index=int(x["index"]),
            start=float(x["start_seconds"]),
            duration=float(x["duration_seconds"]),
            expected=int(x["expected_frames"]),
        )
        for x in manifest["segments"]
    ]
    complete: list[Segment] = []
    invalid: list[tuple[Segment, str]] = []
    for seg in segments:
        ok, reason = segment_valid(root, seg, p)
        if ok:
            complete.append(seg)
        else:
            invalid.append((seg, reason))

    manifest["completed_segments"] = len(complete)
    manifest["actual_total_frames"] = sum(len(frame_files(root / s.name)) for s in complete)
    manifest["updated_at"] = utc_now()
    manifest["base_index_status"] = (
        "complete"
        if len(complete) == len(segments)
        and manifest["actual_total_frames"] == manifest["expected_total_frames"]
        else "pending"
    )
    atomic_write_json(root / MANIFEST_NAME, manifest)
    return complete, invalid


def extract_segment(
    video: Path,
    root: Path,
    seg: Segment,
    params: dict[str, Any],
    ffmpeg: str,
) -> tuple[int, int]:
    final_dir = root / seg.name
    if final_dir.exists():
        shutil.rmtree(final_dir)
    temp_dir = Path(tempfile.mkdtemp(prefix=f".{seg.name}.", dir=root))
    try:
        interval = float(params["interval_seconds"])
        vf = (
            "setpts=PTS-STARTPTS,"
            f"fps=1/{interval:g}:start_time=0,"
            f"scale={int(params['width'])}:-2:flags=fast_bilinear"
        )
        cmd = [
            ffmpeg,
            "-hide_banner",
            "-loglevel",
            "error",
            "-nostdin",
            "-threads",
            str(int(params["threads_per_worker"])),
            "-ss",
            f"{seg.start:.6f}",
            "-i",
            str(video),
            "-t",
            f"{seg.duration:.6f}",
            "-map",
            "0:v:0",
            "-an",
            "-sn",
            "-dn",
            "-vf",
            vf,
            "-frames:v",
            str(seg.expected),
            "-q:v",
            str(int(params["jpeg_qscale"])),
            "-y",
            str(temp_dir / "frame_%04d.jpg"),
        ]
        cp = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if cp.returncode != 0:
            raise RuntimeError(f"ffmpeg failed for {seg.name}: {cp.stderr.strip()}")
        frames = frame_files(temp_dir)
        if len(frames) != seg.expected:
            raise RuntimeError(
                f"{seg.name}: generated {len(frames)} frames, expected {seg.expected}"
            )
        if any(p.stat().st_size <= 0 for p in frames):
            raise RuntimeError(f"{seg.name}: zero-length frame found")
        done = {
            "workflow_version": "v4.9.4",
            "completed_at": utc_now(),
            "segment_index": seg.index,
            "start_seconds": seg.start,
            "duration_seconds": seg.duration,
            "expected_frames": seg.expected,
            "actual_frames": len(frames),
            "interval_seconds": params["interval_seconds"],
            "width": params["width"],
            "jpeg_qscale": params["jpeg_qscale"],
            "threads_per_worker": params["threads_per_worker"],
        }
        atomic_write_json(temp_dir / DONE_NAME, done)
        os.replace(temp_dir, final_dir)
        return seg.index, len(frames)
    except Exception:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("video", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--interval", type=float, default=2.0)
    ap.add_argument("--segment-seconds", type=float, default=90.0)
    ap.add_argument("--workers", type=int, default=0, help="0 = auto")
    ap.add_argument("--threads-per-worker", type=int, default=1)
    ap.add_argument("--max-segments", type=int, default=0, help="0 = one worker batch")
    ap.add_argument("--width", type=int, default=240)
    ap.add_argument("--jpeg-qscale", type=int, default=7)
    ap.add_argument("--ffmpeg", default="ffmpeg")
    ap.add_argument("--ffprobe", default="ffprobe")
    ap.add_argument("--source-sha256", default=None)
    ap.add_argument("--hash-source", action="store_true")
    ap.add_argument("--verify-only", action="store_true")
    return ap.parse_args()


def main() -> int:
    args = parse_args()
    video = args.video.resolve()
    root = args.output.resolve()
    if not video.is_file():
        print(f"ERROR: video not found: {video}", file=sys.stderr)
        return 2
    if args.interval <= 0 or args.segment_seconds <= 0:
        print("ERROR: interval and segment-seconds must be positive", file=sys.stderr)
        return 2
    ratio = args.segment_seconds / args.interval
    if abs(ratio - round(ratio)) > 1e-9:
        print("ERROR: segment-seconds must be an integer multiple of interval", file=sys.stderr)
        return 2
    if args.threads_per_worker < 1 or args.width < 16:
        print("ERROR: invalid threads-per-worker or width", file=sys.stderr)
        return 2

    cpu = os.cpu_count() or 1
    workers = args.workers if args.workers > 0 else min(4, max(1, cpu - 1))
    max_segments = args.max_segments if args.max_segments > 0 else workers
    if workers < 1 or max_segments < 1:
        print("ERROR: workers and max-segments must be positive", file=sys.stderr)
        return 2

    try:
        duration = probe_duration(video, args.ffprobe)
        source_sha = args.source_sha256
        if source_sha is not None:
            source_sha = source_sha.strip().lower()
            if len(source_sha) != 64 or any(c not in "0123456789abcdef" for c in source_sha):
                raise RuntimeError("--source-sha256 must be 64 lowercase/uppercase hex characters")
        if args.hash_source:
            computed = sha256_file(video)
            if source_sha and source_sha != computed:
                raise RuntimeError("provided SHA-256 does not match source bytes")
            source_sha = computed

        root.mkdir(parents=True, exist_ok=True)
        stale_removed = cleanup_stale_temp_dirs(root)
        if stale_removed:
            print(f"cleaned_stale_temp_dirs={stale_removed}")
        manifest_path = root / MANIFEST_NAME
        if manifest_path.exists():
            manifest = load_json(manifest_path)
            validate_manifest(
                manifest,
                video,
                duration,
                args.interval,
                args.segment_seconds,
                args.width,
                args.jpeg_qscale,
                args.threads_per_worker,
                source_sha,
            )
            if source_sha and not manifest.get("source", {}).get("sha256"):
                manifest["source"]["sha256"] = source_sha
                atomic_write_json(manifest_path, manifest)
        else:
            manifest = make_manifest(
                video,
                duration,
                args.interval,
                args.segment_seconds,
                args.width,
                args.jpeg_qscale,
                args.threads_per_worker,
                source_sha,
            )
            atomic_write_json(manifest_path, manifest)

        complete, invalid = refresh_manifest(root, manifest)
        if args.verify_only:
            status = manifest["base_index_status"]
            print(
                f"status={status} completed_segments={manifest['completed_segments']}/"
                f"{manifest['segment_count']} frames={manifest['actual_total_frames']}/"
                f"{manifest['expected_total_frames']}"
            )
            if status != "complete":
                for seg, reason in invalid[:10]:
                    print(f"PENDING {seg.name}: {reason}")
                if len(invalid) > 10:
                    print(f"... {len(invalid) - 10} more pending/damaged segments")
                return 1
            return 0

        if manifest["base_index_status"] == "complete":
            print(
                f"status=complete completed_segments={manifest['completed_segments']}/"
                f"{manifest['segment_count']} frames={manifest['actual_total_frames']}/"
                f"{manifest['expected_total_frames']}"
            )
            return 0

        pending = [seg for seg, _reason in invalid]
        batch = pending[:max_segments]
        # Invalid final directories are removed only for the selected repair batch.
        for seg in batch:
            seg_dir = root / seg.name
            if seg_dir.exists():
                shutil.rmtree(seg_dir)

        print(
            f"building_segments={','.join(s.name for s in batch)} workers={min(workers, len(batch))} "
            f"remaining_before={len(pending)}"
        )
        errors: list[str] = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(workers, len(batch))) as ex:
            futures = {
                ex.submit(
                    extract_segment,
                    video,
                    root,
                    seg,
                    manifest["params"],
                    args.ffmpeg,
                ): seg
                for seg in batch
            }
            for fut in concurrent.futures.as_completed(futures):
                seg = futures[fut]
                try:
                    idx, count = fut.result()
                    print(f"DONE seg_{idx:04d} frames={count}")
                except Exception as exc:  # noqa: BLE001 - report all segment failures
                    errors.append(f"{seg.name}: {exc}")
                    print(f"FAIL {seg.name}: {exc}", file=sys.stderr)

        complete, invalid = refresh_manifest(root, manifest)
        print(
            f"status={manifest['base_index_status']} completed_segments={manifest['completed_segments']}/"
            f"{manifest['segment_count']} frames={manifest['actual_total_frames']}/"
            f"{manifest['expected_total_frames']} remaining={len(invalid)}"
        )
        return 1 if errors else 0
    except (RuntimeError, subprocess.SubprocessError, OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
