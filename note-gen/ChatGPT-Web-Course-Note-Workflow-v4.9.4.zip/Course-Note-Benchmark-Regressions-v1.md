# Course Note Benchmark Regression Harness v1

> 用途：五组固定 benchmark 的外部、只读、不可由当前生成 run 自动修改的 regression oracle。
>
> 本文件不是 Production Prompt。只有命中对应 benchmark 时才加载对应 section。

## 0. Harness Contract

每条 assertion 包含：

```text
assertion_id
severity: P0 / P1 / P2
source_anchor
expected_artifact
required_form
```

验证规则：

- P0/P1 必须逐条回 source anchor 核对并在 final note 中定位 destination；缺失即 Regression Gate R = FAIL。
- P2 记录 variance，默认不阻塞 R Gate。
- `expected_artifact` 是最低要求，不禁止笔记保留更多 source-backed 内容。
- 当前 run 的 Micro-Unit Inventory 没发现 assertion，不能取消 assertion。
- Harness 与 source 冲突时记录 `HARNESS_SOURCE_CONFLICT`，当前 run 不得自行修改 Harness。
- 不允许用图片中“看得到”替代要求 searchable Markdown 的 assertion，除非 `required_form` 明确允许 visual-only。
- 动态过程 assertion 要检查视频时间序列；静态 PDF final frame 不能替代完整过程。

---

# B1 — Princeton Algorithms 4e — 1.5 Union-Find

## Match

```text
benchmark_id: PRINCETON-ALG4-UF-1.5
course: Princeton Algorithms / Algorithms, 4th Edition
chapter: 1.5 Union-Find
expected modules:
  dynamic connectivity
  quick find
  quick union
  improvements
  applications
```

典型 source：`01UnionFind.pdf`、P02–P06 视频/VTT、Algorithms 4e §1.5。

## Locked assertions

### UF-HIER-01 — 官方五模块层级
- severity: P1
- source_anchor: `01UnionFind.pdf` opening agenda + P02–P06 module mapping
- expected_artifact: H1 为 Union-Find 章节；五个官方模块作为主阅读层级，不能被大量 AI 自创 H2 取代。
- required_form: searchable Markdown hierarchy；audit/state units 不得污染阅读层级。

### UF-QF-01 — Quick-Find failed implementation
- severity: P1
- source_anchor: Quick-Find video/VTT + Quick-Find implementation slides
- expected_artifact: 保留错误思路：循环中直接使用会变化的 `id[p]` 作为比较值会导致后续比较错误；说明为什么要先缓存 `pid = id[p]`、`qid = id[q]`。
- required_form: failed attempt → failure mechanism → corrected implementation；不能只给正确代码。

### UF-QF-02 — Quick-Find cost evidence
- severity: P2
- source_anchor: Quick-Find cost slides
- expected_artifact: 区分 exact array accesses 与 order of growth；至少不能把 `N / N / 1` 误称为精确访问次数。
- required_form: searchable text/table。

### UF-QU-01 — Quick-Union tall-tree failure
- severity: P1
- source_anchor: Quick-Union worst-case / tall tree slides + video
- expected_artifact: 说明 naive quick-union 如何产生高树、为什么 `find/connected/union` 会退化。
- required_form: concrete tree/worst-case reasoning，不只写“可能慢”。

### UF-WQU-01 — Weighted depth proof
- severity: P1
- source_anchor: Weighted Quick-Union depth proof slides/video
- expected_artifact: 完整链：`depth +1 → containing tree size at least doubles → size ≥ 2^d → 2^d ≤ N → d ≤ lg N`。
- required_form: proof/derivation steps searchable in Markdown。

### UF-WQU-02 — Logarithmic scale calibration
- severity: P2
- source_anchor: weighted depth intuition slide/video
- expected_artifact: `10^3 → ~10`, `10^6 → ~20`, `10^9 → ~30`。
- required_form: searchable text。

### UF-WQU-03 — Measured root distance
- severity: P1
- source_anchor: experiment slide comparing Quick-Union vs Weighted Quick-Union
- expected_artifact: exact measured comparison `5.11` vs `1.52` with the correct algorithms/context.
- required_form: searchable text/table；不能只存在于截图。

### UF-PC-01 — Full / two-pass path compression DSU
- severity: P1
- source_anchor: `01UnionFind.pdf` path-compression sequence around pp.38–42 + corresponding improvements video
- expected_artifact: 明确区分 full/two-pass compression：先找到 root，再把 examined nodes 直接指向 root；恢复课堂动画中的 decisive mutation，例如 `9 → 6 → 3 → 1 → 0`，并列出 `id[9]:6→0`, `id[6]:3→0`, `id[3]:1→0` 等实际变化。
- required_form: video-derived step trace/state delta；不能只有 final PDF figure 或泛化 prose。

### UF-PC-02 — One-pass path halving
- severity: P1
- source_anchor: path-compression slide immediately following full/two-pass discussion
- expected_artifact: one-pass variant `id[i] = id[id[i]]`，即 node 指向 grandparent；与 UF-PC-01 明确分开。
- required_form: searchable code + explanation；不得把 halving 冒充 full compression。

### UF-PC-03 — Performance payoff
- severity: P1
- source_anchor: WQUPC performance slide
- expected_artifact: 保留“约 30 years → 6 seconds”这一 engineering-scale evidence，并正确关联算法改进。
- required_form: searchable quantitative evidence。

### UF-PERC-01 — Percolation 三态 visual legend
- severity: P1
- source_anchor: Percolation Monte Carlo / legend slides
- expected_artifact: 文本化三态：`blocked`；`empty open = open but not connected to top`；`full open = open and connected to top`。
- required_form: searchable Markdown，不能只靠颜色/截图。

### UF-PERC-02 — Phase-transition concrete states
- severity: P1
- source_anchor: percolation visual states
- expected_artifact: `p=0.4 / 0.6 / 0.8` 三个具体状态及其教学意义；threshold `≈ 0.592746`。
- required_form: exact numbers + concise explanation；视觉可辅佐。

### UF-PERC-03 — Connectivity implementation evidence
- severity: P1
- source_anchor: percolation implementation slides/video
- expected_artifact: 朴素 `N^2 connected()` 检查 → virtual top/bottom → 最终 1 次 connectivity query 的优化；打开一个 site 最多检查 4 个邻居 / 最多 4 次 union。
- required_form: searchable algorithm/quantitative description。

### UF-APP-01 — Official applications list
- severity: P1
- source_anchor: applications module final list/slides
- expected_artifact: 紧凑保留官方应用列表，而不是只剩 percolation；至少覆盖 source 中出现的主要项，如 network connectivity / connected-component labeling、Kruskal、least common ancestor、finite-state automata equivalence、Hoshen–Kopelman、Hindley–Milner type inference、Fortran equivalence、morphological labeling / `bwlabel()` 等 source 实际列出的项目。
- required_form: compact searchable list；无需展开课程外背景。

---

# B2 — MIT 18.06 — Lecture 1 Geometry of Linear Equations

## Match

```text
benchmark_id: MIT-18.06-L01-GEOMETRY
course: MIT 18.06 Linear Algebra
lecture: Geometry of Linear Equations / Lecture 1
primary lecture/transcript: older lecture recording
supporting summary: MIT OCW 18.06SC Fall 2011
```

## Locked assertions

### LA-PROV-01 — Provenance separation
- severity: P0
- source_anchor: lecture transcript metadata + 18.06SC supporting summary metadata
- expected_artifact: 不把后来的 OCW summary/textbook 内容伪装成原 lecture 当时教师口述；不同年份/版本明确区分。
- required_form: source/provenance note or internally correct attribution。

### LA-ROW-01 — 2D row picture
- severity: P1
- source_anchor: opening 2x2 example
- expected_artifact: `2x-y=0`, `-x+2y=3` 两条直线；交点 `(1,2)` 是同时满足两方程的解。
- required_form: equation + geometric interpretation；可配图。

### LA-COL-01 — Column picture / linear combination
- severity: P1
- source_anchor: column-picture segment
- expected_artifact: 把 `Ax=b` 左侧解释为列向量的 linear combination；该例用 `x=1,y=2` 组合两列得到 `b=(0,3)`。
- required_form: explicit combination, not only matrix notation。

### LA-3D-01 — Three equations / planes
- severity: P1
- source_anchor: 3x3 row-picture segment
- expected_artifact: 三个线性方程对应三平面；一般位置下三平面交于一点；row picture 在高维迅速变得难以可视化。
- required_form: searchable explanation。

### LA-3D-02 — 3D column picture example
- severity: P1
- source_anchor: 3x3 column-picture segment
- expected_artifact: 三个 3D columns 的 linear combination；课堂特制 `b` 等于第三列时解为 `(0,0,1)`，随后改变 `b` 演示同一 A 的不同 combination。
- required_form: concrete example preserved。

### LA-SPAN-01 — Every b / singular vs invertible
- severity: P1
- source_anchor: all possible right-hand sides discussion
- expected_artifact: “能否对每个 b 解 `Ax=b`” ↔ columns 的 combinations 是否填满空间；若 columns 共面/依赖则只能到达子空间，matrix singular/not invertible。
- required_form: causal/geometric reasoning。

### LA-MV-01 — Matrix-vector multiplication two views
- severity: P1
- source_anchor: final matrix multiplication example
- expected_artifact: `[[2,5],[1,3]] [1,2]^T = [12,7]^T`；column-combination view 与 row dot-product view 都保留，并强调 Strang 偏好的 column interpretation。
- required_form: exact worked example。

---

# B3 — MIT 18.01 — Lecture 1 Derivatives and Rates of Change

## Match

```text
benchmark_id: MIT-18.01-L01-DERIVATIVE
course: MIT 18.01 Single Variable Calculus
lecture video: Fall 2007
supporting notes: Fall 2010
```

## Locked assertions

### CALC-PROV-01 — 2007 video vs 2010 supporting notes
- severity: P0
- source_anchor: video/notes metadata
- expected_artifact: 明确区分 Fall 2007 lecture 与 Fall 2010 supporting notes；不把 supporting-note wording 冒充视频原话。
- required_form: provenance preserved。

### CALC-GEO-01 — Secant to tangent
- severity: P1
- source_anchor: geometric interpretation segment
- expected_artifact: tangent 不是“只与曲线相交一点的线”，而是 secant lines 在 Q→P 时的极限；导数是 tangent slope。
- required_form: geometric reasoning + key diagram if useful。

### CALC-DQ-01 — Difference quotient
- severity: P1
- source_anchor: slope-as-ratio / main formula segment
- expected_artifact: `Δf = f(x0+Δx)-f(x0)`，secant slope `Δf/Δx`，以及 `f'(x0)=lim_{Δx→0}[f(x0+Δx)-f(x0)]/Δx`。
- required_form: derivation sequence, not formula-only。

### CALC-RECIP-01 — `1/x` complete derivative derivation
- severity: P1
- source_anchor: Example `f(x)=1/x`
- expected_artifact: 完整公共分母/消去 `Δx` 的代数过程，最终 `-1/x0^2`；不能跳过使 `0/0` 消失的关键步骤。
- required_form: step-by-step derivation。

### CALC-RECIP-02 — Why not set Δx=0 early
- severity: P1
- source_anchor: derivative example discussion
- expected_artifact: 解释过早代入 `Δx=0` 会得到 `0/0`，必须先 algebraic cancellation；保留至少一个课堂 sanity check / student question（如 `x0=3` 的 limit 解释或 fraction simplification）。
- required_form: explicit reasoning。

### CALC-TRI-01 — Tangent triangle problem
- severity: P1
- source_anchor: harder problem segment
- expected_artifact: 对 `y=1/x` tangent line 求 x/y intercept，得到 `2x0`、`2y0`，三角形面积恒为 `2`。
- required_form: worked derivation + geometry。

### CALC-VAR-01 — Variable reuse discussion
- severity: P1
- source_anchor: tangent triangle tail
- expected_artifact: 解释同一个 `y` 在 hyperbola、tangent line、x-axis equations 中可代表不同语境变量；提醒从 context 判断。
- required_form: searchable conceptual note。

### CALC-NOT-01 — Derivative notations
- severity: P1
- source_anchor: notation segment
- expected_artifact: `dy/dx`, `df/dx`, `f'(x0)`, `f'`, `Df` 等主要 notation 及其语义差异。
- required_form: concise table/list。

### CALC-POWER-01 — Binomial theorem to power rule
- severity: P1
- source_anchor: `f(x)=x^n` example
- expected_artifact: difference quotient → `(x+Δx)^n` 展开 → `x^n + nΔx x^{n-1} + O((Δx)^2)` → cancel → limit → `d(x^n)/dx = nx^{n-1}`；解释 `nΔx x^{n-1}` 的 combinatorial 来源。
- required_form: proof/derivation chain。

---

# B4 — Berkeley CS164 — P6 Booleans (Compiler)

## Match

```text
benchmark_id: BERKELEY-CS164-P6-BOOLEANS
course: Berkeley CS164 Fall 2025
lecture/module: P6 Booleans (Compiler)
repository: class-compiler-f25
```

## Locked assertions

### CS164-END-01 — Exact lecture endpoint
- severity: P0
- source_anchor: official repository history + lecture boundary
- expected_artifact: lecture-end commit exactly `91111f13bbf58b6835e5fda4a1c92c15411b8991`。
- required_form: exact commit hash and boundary statement。

### CS164-END-02 — Do not substitute prep commit
- severity: P0
- source_anchor: immediately following commit history
- expected_artifact: `96dea5deb37e...` 是 next-session preparation（增加之后需要的 asm directives），不能当作 P6 lecture-end snapshot。
- required_form: explicit distinction if repository boundary discussed。

### CS164-SCOPE-01 — Compiler feature scope at endpoint
- severity: P1
- source_anchor: endpoint commit message + lecture code
- expected_artifact: endpoint 已实现 `Number`, `true`, `false`, `add1`, `sub1`；尚未加入 `not`, `num?`, `zero?`, `if`。
- required_form: searchable scope list；later features cannot be backfilled as lecture-complete。

### CS164-TAIL-01 — Host integer vs target runtime representation
- severity: P1
- source_anchor: video tail approx. 80–84 min
- expected_artifact: 区分 OCaml host integer representation/range 与 compiled tagged runtime representation；不能把二者当成同一 bit-width/word semantics。
- required_form: explicit two-layer comparison。

### CS164-TAIL-02 — Host-side shift risk
- severity: P1
- source_anchor: same video-tail claim chain
- expected_artifact: 具体讨论 host-side `n lsl num_shift` 的 representability/overflow semantics 风险，而不是只写“compile time vs run time”。
- required_form: exact operation + mechanism/limitation。

### CS164-TAIL-03 — Emit target assembly alternative
- severity: P1
- source_anchor: same video-tail claim chain, teacher proposes alternative
- expected_artifact: alternative design：不要由 OCaml host 预先完成该 shift，而是 emit target assembly，让目标程序执行 shift；与 CS164-TAIL-02 使用同一 claim chain。
- required_form: limitation → matching alternative；不能用其他 boolean-tag-layout alternative 冒充。

### CS164-DSU-01 — Live-coding evolution
- severity: P1
- source_anchor: lecture live coding around booleans/compiler implementation
- expected_artifact: 保留关键代码演化与 reasoning，而不是只给最终 repository snapshot；尤其是 tagged representation 如何驱动 compile cases。
- required_form: step/diff or concise evolution trace。

---

# B5 — Princeton Algorithms 4e — 5.4 Regular Expressions

## Match

```text
benchmark_id: PRINCETON-ALG4-RE-5.4
course: Princeton Algorithms / Algorithms, 4th Edition
chapter: 5.4 Regular Expressions
expected modules:
  regular expressions
  REs and NFAs
  NFA simulation
  NFA construction
  applications
```

典型 source：P44–P48 视频/VTT、`10RegularExpressions.pdf`、Algorithms 4e §5.4。

## Locked assertions

### RE-HIER-01 — 官方五模块层级
- severity: P1
- source_anchor: chapter opening agenda + P44–P48 module mapping
- expected_artifact: 五个官方模块作为主 H2 层级；不能恢复到几十个 AI-generated H2。
- required_form: source-native Markdown hierarchy。

## P44 concrete-unit locked set

以下 assertions 必须分别存在；不能用一个 `applications/examples/caveats` catch-all 满足多个断言。

### RE-P44-01 — Syntax highlighting
- severity: P1
- source_anchor: P44 opening concrete applications
- expected_artifact: source-code syntax highlighting / GNU source-highlight concrete episode。
- required_form: separate searchable episode。

### RE-P44-02 — Google public source-code regex search
- severity: P1
- source_anchor: P44 concrete search demo
- expected_artifact: Google/public source-code regex search episode。
- required_form: separate searchable episode。

### RE-P44-03 — Regex Golf
- severity: P1
- source_anchor: P44 Regex Golf segment
- expected_artifact: Regex Golf 作为独立 motivational/concrete unit。
- required_form: separate searchable episode。

### RE-P44-04 — Illegal job-candidate screening
- severity: P1
- source_anchor: P44 screening example
- expected_artifact: 课程展示的 illegal job-candidate screening / regex-search example 本身。
- required_form: separate searchable episode；课程外法律背景不是必需。

### RE-P44-05 — Google wildcard / OR semantics
- severity: P1
- source_anchor: P44 Google search semantics example
- expected_artifact: Google search 中 wildcard `*` / OR `|` 的 concrete semantics/demo。
- required_form: exact operators + example context。

### RE-P44-06 — XKCD / large email corpus
- severity: P1
- source_anchor: P44 XKCD / email-search segment
- expected_artifact: XKCD / 在大型 email corpus 中搜索地址的教学 episode。
- required_form: separate searchable episode。

### RE-P44-07 — Huge RFC822 email regex
- severity: P1
- source_anchor: P44 email-regex slide
- expected_artifact: 巨大的 RFC822 email regular expression 作为“复杂度/可读性”证据。
- required_form: 不必全文抄写巨大 regex，但必须明确指出并保留其教学作用；若 source 用图展示，可保留图并文本化结论。

### RE-P44-08 — Readability/debugging caveat
- severity: P1
- source_anchor: P44 caveat discussion
- expected_artifact: “easier to write than read” / difficult-to-debug / “now you have two problems” 类 source-backed caveat 的核心含义。
- required_form: concise searchable caveat；不要用 generic “regex can be complex” 代替全部内容。

### RE-DFA-01 — Failed direct RE→DFA plan
- severity: P1
- source_anchor: REs and NFAs module
- expected_artifact: 完整动机链：直接 build DFA 很有吸引力、DFA simulation 可线性扫描/no backup，但 DFA state count 可能指数增长，因此改为 RE→NFA→NFA simulation。
- required_form: baseline → appeal → failure → evidence/consequence → revised design。

### RE-SIM-01 — `AABD` NFA simulation
- severity: P1
- source_anchor: P46 simulation video/slide sequence
- expected_artifact: exact state evolution：initial ε-closure `{0,1,2,3,4,6}`；A raw `{3,7}` → closure `{2,3,4,7}`；A raw `{3}` → closure `{2,3,4}`；B raw `{5}` → closure `{5,8,9}`；D raw `{10}` → closure `{10,11}`；accept。
- required_form: DSU step table/trace；raw match 与 ε-closure 必须分开；视频关键帧优先于只用最终 PDF。

### RE-CON-01 — `((A*B|AC)D)` construction DSU
- severity: P1
- source_anchor: P47 approx. 05:26–09:16 + corresponding slide final state
- expected_artifact: 恢复按字符扫描的 stack / `lp` / `*` / `|` / `)` 处理与 epsilon-edge additions；至少覆盖外层/内层 `(` push、`A*` closure、`|` push、`)` pop 与 alternation edges、最终 accept-side connection。
- required_form: video-derived ordered step trace + explicit stack/state deltas + decisive keyframes；不能只有 prose + final PDF NFA。

### RE-CON-02 — Constructor implementation
- severity: P1
- source_anchor: NFA construction implementation slides/textbook
- expected_artifact: 保留课堂核心 constructor implementation，包含 `Stack<Integer> ops`, `lp`, parentheses/alternation/closure edge construction。
- required_form: complete core implementation or source-faithful near-complete teaching implementation。

### RE-OR-01 — Classroom 2-way OR limitation
- severity: P1
- source_anchor: constructor limitation / industrial-strength extension discussion
- expected_artifact: 明确当前课堂 constructor 只支持括号内 0/1 个 `|` 的 2-way OR；multiway OR 是 extension。
- required_form: explicit scope limitation + extension；不能只写“industrial engines are richer”。

### RE-REC-01 — `recognizes()` implementation
- severity: P1
- source_anchor: NFA simulation implementation
- expected_artifact: 保留 concrete Java algorithm structure：initial epsilon reachability、per-character match set、`DirectedDFS` closure、accept-state check；不能压成几个抽象 helper 名称而失去课堂 implementation。
- required_form: complete/core teaching implementation。

### RE-P48-01 — Industrial-strength grep / concrete usage
- severity: P1
- source_anchor: P48 applications opening
- expected_artifact: 至少保留 source 中的 concrete grep/validation/harvesting usage，而不只留下工具名。
- required_form: concrete CLI/example text。

### RE-VAL-01 — Validation CLI examples
- severity: P1
- source_anchor: P48 Validate examples
- expected_artifact: source 给出的具体 `java Validate ...` 类 input/validation examples（identifier/email/SSN 等实际出现的例子）应保留关键 literal tuples。
- required_form: exact or source-faithful CLI/input→result examples。

### RE-HARV-01 — Complete Harvester teaching client
- severity: P1
- source_anchor: P48 Harvester client slide
- expected_artifact: 完整 client skeleton：class/main、`args[0]` regexp、input file loading / `readAll()`、`Pattern.compile`、`Matcher`、`while (matcher.find())`、`group()` output。
- required_form: complete teaching client skeleton；不能只剩 Pattern/Matcher API fragment。

### RE-HARV-02 — DNA and URL CLI/output tuples
- severity: P1
- source_anchor: P48 Harvester concrete examples
- expected_artifact: DNA regex harvesting 与 URL harvesting 的 concrete command + representative output，保持 input→output pairing。
- required_form: searchable CLI/literal examples。

### RE-REDOS-01 — ReDoS exact growth experiment
- severity: P1
- source_anchor: P48 ReDoS experiment slide
- expected_artifact: 六条逐渐增长的 literal input 与 runtime 一一配对，runtime 为 `1.6 / 3.7 / 9.7 / 23.2 / 62.2 / 161.6 s`；不能用 `a...ac` / “longer input” 代替 exact source literals。
- required_form: exact literal input→runtime table。

### RE-BACKREF-01 — Backreference concrete examples
- severity: P1
- source_anchor: P48 backreference discussion
- expected_artifact: source 中用于说明 backreference 超出 regular-language model 的具体例子/语义。
- required_form: concrete example + limitation meaning。


## Cross-course visual regression — v4.9.1

### VIS-FULLFRAME-01 — Final coverage assets must preserve the full video frame
- severity: P0
- source_anchor: any retained video-derived visual asset
- expected_artifact: after a representative timestamp is chosen, the final image is exported directly from the source video without crop / semantic ROI / subtitle-strip removal / resize / scale / pad. `asset_frame_size` must equal `source_frame_size`.
- required_form: `capture_mode=full_frame` in visual coverage audit + mechanical dimension check.
- regression_origin: MIT 18.01 P01 source `640x480` was reduced by v4.9 to `640x420` to remove the subtitle strip, which also removed classroom/board context. v4.9.1 treats this as a hard failure.

### VIS-FULLFRAME-02 — Occlusion is repaired by frame selection, not geometry cropping
- severity: P1
- source_anchor: retained board / slide / terminal / IDE states with teacher, subtitle, cursor, or other transient occlusion
- expected_artifact: choose a nearby clearer full frame, retain an additional full frame if needed, and transcribe critical content to Markdown. Do not crop around the occluder.
- required_form: full-frame asset(s) + searchable Markdown for critical text/formula/output.

---

# Harness Maintenance Policy

本文件只在以下情况下人工更新：

1. 独立复核重新回 primary/official source，确认一个新的 P0/P1 benchmark unit；
2. source 版本发生变化，原 assertion 已不适用于当前固定 benchmark；
3. 发现 assertion 本身事实错误或 source anchor 错误。

不得因为某次生成难以通过而删除 assertion。
不得为了普通新课程扩张本 Harness；新课程先由 Production Prompt 处理。

版本更新时保留 assertion ID 稳定性；语义变化需要 changelog。
